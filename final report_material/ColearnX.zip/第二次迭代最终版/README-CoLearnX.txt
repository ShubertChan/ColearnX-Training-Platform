CoLearnX React Prototype

How to view:
1. Unzip the package.
2. Open index.html in a browser.
3. Use the left navigation to browse the CoLearnX prototype.

Notes:
- This is a static demo with mock data.
- It does not require a backend server.
- Role switching is available in the left sidebar.
