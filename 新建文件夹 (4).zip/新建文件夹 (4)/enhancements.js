(() => {
  const DAY = 86400000;
  const DEMO_NOW = new Date("2026-07-13T12:00:00+08:00");
  const BALANCE_KEY = "colearnx-point-balance";
  const POINT_ORDERS_KEY = "colearnx-point-orders";
  const DRAFT_KEY = "colearnx-course-draft-v3";

  const courses = {
    "ai-basics": {
      title: "AI Basics Training Course", trainer: "Trainer A", category: "AI", price: 80,
      purchased: false, mode: "offline", access: "cloud", duration: "45 min", total: 45, watched: 0,
      structure: "single", location: "CoLearnX Studio A",
      sessions: [{ topic: "AI foundations and prompt practice", date: "12 Jul 2026", time: "10:00-10:45", duration: "45 min", location: "CoLearnX Studio A" }]
    },
    "web-design": {
      title: "Web Design Bootcamp", trainer: "Trainer B", category: "Design", price: 120,
      purchased: true, mode: "offline", access: "cloud", duration: "3 hr", total: 180, watched: 45,
      structure: "series", location: "CoLearnX Studio B",
      sessions: [
        { topic: "Layout foundations", date: "14 Jul 2026", time: "19:00-19:45", duration: "45 min", location: "Studio B", status: "Completed" },
        { topic: "Typography and colour", date: "16 Jul 2026", time: "19:00-19:45", duration: "45 min", location: "Studio B", status: "Next" },
        { topic: "Responsive design", date: "21 Jul 2026", time: "19:00-19:45", duration: "45 min", location: "Studio B", status: "Upcoming" },
        { topic: "Portfolio critique", date: "23 Jul 2026", time: "19:00-19:45", duration: "45 min", location: "Studio B", status: "Upcoming" }
      ]
    },
    cybersecurity: {
      title: "Cybersecurity Intro", trainer: "Trainer C", category: "Security", price: 100,
      purchased: true, mode: "online", delivery: "live", replay: false, duration: "1 hr", total: 60, watched: 0,
      structure: "single", startsAt: "2026-08-03T20:00:00+08:00",
      sessions: [{ topic: "Live cybersecurity essentials", date: "03 Aug 2026", time: "20:00-21:00", duration: "60 min", location: "Live classroom" }]
    },
    "javascript-starter": {
      title: "JavaScript Starter", trainer: "Trainer D", category: "Code", price: 70,
      purchased: true, mode: "online", delivery: "live", replay: true, duration: "2 hr", total: 120, watched: 0,
      structure: "series", startsAt: "2026-08-15T09:00:00+08:00",
      sessions: [
        { topic: "Variables and data types", date: "15 Aug 2026", time: "09:00-09:30", duration: "30 min", location: "Live classroom", status: "Replay after live" },
        { topic: "Functions", date: "17 Aug 2026", time: "09:00-09:30", duration: "30 min", location: "Live classroom", status: "Replay after live" },
        { topic: "Arrays and objects", date: "19 Aug 2026", time: "09:00-09:30", duration: "30 min", location: "Live classroom", status: "Replay after live" },
        { topic: "Browser project", date: "21 Aug 2026", time: "09:00-09:30", duration: "30 min", location: "Live classroom", status: "Replay after live" }
      ]
    }
  };
  const ids = Object.keys(courses);
  const editorState = { mode: "online", hasReplay: true, offlineType: "single", access: "cloud", sessions: 3 };
  const pointPlans = [
    { id: "starter", points: 100, price: 9.9, bonus: 0, tag: "For quick trials" },
    { id: "popular", points: 320, price: 29.9, bonus: 20, tag: "Most popular" },
    { id: "pro", points: 680, price: 59.9, bonus: 80, tag: "Best value" }
  ];
  const sellerLedger = [
    { date: "13 Jul 2026", seller: "Trainer B", item: "Web Design Bootcamp", buyer: "Member", points: 120, state: "Frozen", trigger: "Awaiting refund window / first access" },
    { date: "13 Jul 2026", seller: "Trainer C", item: "Cybersecurity Intro", buyer: "Member", points: 100, state: "Frozen", trigger: "Live course not started" },
    { date: "12 Jul 2026", seller: "Creator B", item: "Pixel Art Guide", buyer: "Member", points: 42, state: "Released", trigger: "First file access completed" },
    { date: "11 Jul 2026", seller: "Trainer A", item: "AI Basics Training Course", buyer: "Member", points: 80, state: "Refunded", trigger: "Refund approved; points returned to buyer" }
  ];
  const paymentChannels = [
    { channel: "Credit / Debit Card", status: "Active", settlement: "External payment only for point top-up" },
    { channel: "PayNow", status: "Active", settlement: "QR confirmation before points are issued" },
    { channel: "Apple Pay / Google Pay", status: "Active", settlement: "Wallet checkout for point top-up" }
  ];
  const abnormalRefunds = [
    { id: "AR-1042", case: "Card chargeback after points issued", action: "Freeze equivalent points and review" },
    { id: "AR-1043", case: "Payment timeout but provider later confirms paid", action: "Reconcile and issue missing points" },
    { id: "AR-1044", case: "Duplicate top-up order", action: "Refund external payment or void duplicate points" }
  ];

  const icon = (name, size = 17) => {
    const paths = {
      clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
      play: '<path d="m8 5 11 7-11 7z"/>',
      check: '<path d="m5 12 4 4L19 6"/>',
      calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
      download: '<path d="M12 3v12m0 0 5-5m-5 5-5-5M5 21h14"/>',
      users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8M22 21v-2a4 4 0 0 0-3-3.87"/>',
      grip: '<path d="M9 5h.01M15 5h.01M9 12h.01M15 12h.01M9 19h.01M15 19h.01"/>'
    };
    return `<svg class="cx-icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.check}</svg>`;
  };

  const styles = `
    .cx-toolbar{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;margin:0 0 18px;flex-wrap:wrap}.cx-filter-stack{display:flex;gap:13px;flex-wrap:wrap;align-items:flex-end}.cx-filter-block label{display:block;color:#667085;font-size:11px;font-weight:800;letter-spacing:.04em;margin-bottom:6px;text-transform:uppercase}.cx-filter-group{display:flex;gap:6px;flex-wrap:wrap}.cx-filter{border:1px solid #dce2ef;background:#fff;color:#586174;min-height:34px;padding:0 12px;border-radius:999px;font-size:12px}.cx-filter.active{border-color:#3857f6;background:#eef1ff;color:#263db7}.cx-muted{color:#667085;font-size:13px}
    .cx-badge{display:inline-flex;align-items:center;gap:5px;white-space:nowrap;border-radius:999px;padding:5px 9px;background:#f1f4f9;color:#526074;font-size:12px;font-weight:800}.cx-badge.replay{background:#f1ebff;color:#6d3fc0}.cx-badge.live{background:#fff0f0;color:#c03b49}.cx-badge.owned{background:#e9f8ef;color:#147a43}.cx-badge.series{background:#fff6df;color:#936300}.cx-badge.offline{background:#eaf6ff;color:#176a9c}.cx-badge.danger{background:#fff0f0;color:#b42318}
    .cx-course-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.cx-course-card{background:#fff;border:1px solid #e1e6f0;border-radius:14px;overflow:hidden;box-shadow:0 12px 32px #2a31480c;transition:.18s ease}.cx-course-card:hover{transform:translateY(-2px);box-shadow:0 18px 42px #2a314817}.cx-cover{height:132px;padding:18px;display:flex;justify-content:space-between;align-items:flex-start;background:linear-gradient(135deg,#273bb2,#6d5dfc);color:#fff}.cx-cover.design{background:linear-gradient(135deg,#7b2cbf,#d16ba5)}.cx-cover.security{background:linear-gradient(135deg,#075985,#0891b2)}.cx-cover.code{background:linear-gradient(135deg,#111827,#374151)}.cx-cover-mark{font-size:35px;font-weight:900;opacity:.92}.cx-card-body{padding:19px}.cx-card-body h3{font-size:19px;margin:0 0 5px}.cx-trainer{color:#667085;font-size:13px}.cx-card-meta{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin:16px 0}.cx-meta{display:flex;gap:7px;align-items:center;color:#586174;font-size:13px}.cx-card-footer{display:flex;justify-content:space-between;align-items:center;gap:12px;border-top:1px solid #edf0f6;padding-top:15px}.cx-price{font-size:20px;font-weight:900;color:#263db7}.cx-empty{display:none;text-align:center;background:#fff;border:1px dashed #bcc5d6;border-radius:14px;padding:55px 20px}.cx-empty.show{display:block}.cx-empty strong{display:block;font-size:18px;margin-bottom:6px}
    .cx-progress{min-width:140px}.cx-progress-head{display:flex;justify-content:space-between;gap:10px;margin-bottom:7px;color:#667085;font-size:12px}.cx-track{height:7px;background:#e7ebf3;border-radius:999px;overflow:hidden}.cx-track span{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,#3857f6,#7c5cff)}.cx-progress-card{margin-top:14px;padding-top:14px;border-top:1px solid #dce2ef}.cx-owned-box strong{font-size:20px!important;color:#15803d!important}.cx-owned-box .cx-badge{margin-bottom:10px}.cx-date-note{min-width:170px;color:#667085;font-size:12px;line-height:1.45}.cx-date-note strong{display:block;color:#172033;font-size:13px;margin-bottom:3px}.cx-refund-note{min-width:150px}.cx-refund-note small{display:block;color:#667085;margin-top:5px;line-height:1.35}.cx-status-list{display:grid;gap:7px;margin-top:12px;text-align:left}.cx-status-list span{color:#667085;font-size:12px}.cx-status-list b{display:block;color:#172033;font-size:13px}
    .cx-schedule{margin-top:18px}.cx-schedule-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px}.cx-schedule h3{margin:0}.cx-series-summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin:12px 0 18px}.cx-series-stat{background:#f6f8fc;border-radius:9px;padding:12px}.cx-series-stat strong{display:block;font-size:17px}.cx-series-stat span{color:#667085;font-size:12px}.cx-session{display:grid;grid-template-columns:34px minmax(0,1fr) auto;gap:12px;align-items:start;padding:14px 0;border-top:1px solid #edf0f6}.cx-session svg{color:#3857f6;margin-top:2px}.cx-session strong{display:block}.cx-session span{display:block;color:#667085;font-size:13px;margin-top:3px}.cx-session-time{text-align:right;color:#526074;font-size:12px;white-space:nowrap}
    .cx-rule{margin-top:18px;border-radius:12px;padding:17px;border:1px solid #dce2ef;background:#fff}.cx-rule.eligible{border-color:#9dd9b6;background:#f2fbf6}.cx-rule.ineligible{border-color:#efb2b2;background:#fff7f7}.cx-rule h3{margin:0 0 7px}.cx-rule p{margin:4px 0}.cx-warning{display:flex;gap:10px;background:#fff8e6;border:1px solid #f5d38b;border-radius:9px;color:#7a4d00;padding:12px;margin-top:12px;font-size:13px}
    .cx-modal-backdrop{position:fixed;inset:0;background:#17203380;z-index:40;display:grid;place-items:center;padding:20px}.cx-modal{background:#fff;border-radius:14px;box-shadow:0 24px 80px #1720334d;max-width:620px;width:100%;padding:24px}.cx-modal h2{margin-bottom:8px}.cx-modal .actions{justify-content:flex-end}.cx-preview-list{background:#f6f8fc;border-radius:10px;padding:14px;margin:14px 0}.cx-preview-list p{margin:6px 0}
    .cx-editor-section{border:1px solid #e1e6f0;border-radius:10px;background:#fafbfe;padding:18px}.cx-section-heading{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:14px}.cx-section-heading h3{margin:0 0 4px}.cx-section-heading p{margin:0;font-size:13px}.cx-segmented{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.cx-option{border:1px solid #dce2ef;background:#fff;min-height:72px;padding:12px;text-align:left;display:block}.cx-option strong,.cx-option span{display:block}.cx-option span{font-size:12px;color:#667085;margin-top:3px;font-weight:500}.cx-option.active{border:2px solid #3857f6;background:#eef1ff;color:#263db7}
    .cx-fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:14px}.cx-field label{display:block;color:#596579;font-size:12px;font-weight:800;margin-bottom:6px}.cx-field input,.cx-field select{width:100%;min-height:44px;margin:0!important;border:1px solid #dce2ef;border-radius:8px;background:#fff;padding:10px 12px}.cx-field .invalid{border-color:#d92d20;background:#fff7f7}.cx-error{display:block;color:#b42318;font-size:12px;margin-top:5px}.cx-series-list{display:flex;flex-direction:column;gap:9px;margin-top:14px}.cx-series-row{display:grid;grid-template-columns:32px 28px minmax(0,1fr) 180px 32px;gap:8px;align-items:center;background:#fff;border:1px solid #e5e9f1;border-radius:9px;padding:8px}.cx-grip{color:#98a2b3;cursor:grab}.cx-series-row b{display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:#eef1ff;color:#3857f6;font-size:12px}.cx-icon-btn{border:0;background:#f3f5fa;color:#596579;min-height:30px;width:30px;padding:0}.cx-add-session{align-self:flex-start;margin-top:10px}.cx-summary{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:13px;color:#667085;font-size:13px}.cx-autosave{display:flex;align-items:center;gap:7px;color:#667085;font-size:12px;margin-left:auto}.cx-validation{display:none;background:#fff0f0;border:1px solid #efb2b2;border-radius:9px;color:#9f1d1d;padding:12px}.cx-validation.show{display:block}
    .tabs{flex-wrap:wrap}.tabs button.active{background:#3857f6;color:#fff}.cx-purchases-page .grid.two{grid-template-columns:1fr}.cx-purchases-page .table-card{overflow-x:auto}.cx-purchases-page .table-card table{min-width:940px}.cx-purchases-page .table-card th:last-child,.cx-purchases-page .table-card td:last-child{width:120px;text-align:right}.cx-purchases-page .table-card .mini{white-space:nowrap}.cx-toast{position:fixed;right:24px;bottom:24px;z-index:60;background:#172033;color:#fff;padding:14px 18px;border-radius:10px;box-shadow:0 14px 40px #17203338;font-weight:700;animation:cx-in .2s ease}@keyframes cx-in{from{opacity:0;transform:translateY(8px)}}
    .cx-topup-hero{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(260px,.6fr);gap:18px;margin-bottom:18px}.cx-topup-card,.cx-payment-card{background:#fff;border:1px solid #e4e7ef;border-radius:12px;box-shadow:0 16px 40px #2a31480f;padding:22px}.cx-topup-card h2,.cx-payment-card h3{margin:0 0 8px}.cx-stepper{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin:0 0 18px}.cx-step{background:#fff;border:1px solid #e4e7ef;border-radius:12px;padding:12px;color:#667085}.cx-step b{display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:#eef1ff;color:#2b41c3;margin-bottom:6px}.cx-step.active{border:2px solid #3857f6;color:#172033;background:#f5f7ff}.cx-step.done b{background:#16a34a;color:#fff}.cx-plan-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin:18px 0}.cx-plan{border:1px solid #dce2ef;background:#fff;border-radius:12px;padding:18px;text-align:left;cursor:pointer}.cx-plan:hover,.cx-plan.active{border:2px solid #3857f6;background:#f5f7ff}.cx-plan strong{display:block;font-size:30px}.cx-plan small{color:#667085}.cx-plan .price{color:#263db7;font-weight:900;margin-top:12px}.cx-pay-methods{display:grid;gap:12px;margin:14px 0}.cx-method{border:1px solid #dce2ef;border-radius:12px;padding:16px;display:flex;justify-content:space-between;gap:12px;align-items:center;cursor:pointer;background:#fff}.cx-method strong{display:block}.cx-method small{color:#667085}.cx-method.active,.cx-method:hover{border:2px solid #3857f6;background:#f5f7ff}.cx-payment-form{display:grid;gap:12px;margin-top:14px}.cx-payment-form label{display:block;color:#596579;font-size:12px;font-weight:800}.cx-payment-form input{width:100%;min-height:44px;margin-top:6px;border:1px solid #dce2ef;border-radius:8px;padding:10px 12px}.cx-form-two{display:grid;grid-template-columns:1fr 1fr;gap:12px}.cx-summary-row{display:flex;justify-content:space-between;gap:12px;border-top:1px solid #edf0f6;padding:11px 0}.cx-summary-row.total{font-size:18px;font-weight:900;color:#172033}.cx-safe{background:#f0fdf4;border:1px solid #bbf7d0;color:#166534;border-radius:10px;padding:12px;margin-top:14px}.cx-wallet-cta{display:flex;justify-content:space-between;align-items:center;gap:14px;margin:0 0 18px;padding:18px;background:#fff;border:1px solid #e4e7ef;border-radius:12px;box-shadow:0 16px 40px #2a31480f}.cx-wallet-cta h3{margin:0 0 4px}.cx-success-box{background:#fff;border:1px solid #e4e7ef;border-radius:12px;box-shadow:0 16px 40px #2a31480f;padding:50px 24px;text-align:center;max-width:720px;margin:40px auto}.cx-success-box strong{font-size:34px;color:#16a34a}.cx-wide{width:100%}
    body{background:radial-gradient(circle at 82% 8%,#e8edff 0,#f7f8fc 34%,#f8fafc 100%)}main{background:linear-gradient(180deg,#f7f8ff,#f8fafc);min-height:100vh}.sidebar{box-shadow:10px 0 30px #17203308}.sidebar nav a.active{background:linear-gradient(135deg,#3857f6,#6d5dfc)!important;color:#fff!important;box-shadow:0 10px 24px #3857f633}.topbar{background:rgba(255,255,255,.78);backdrop-filter:blur(12px);border:1px solid #e8ecf5;border-radius:18px;padding:18px 20px;box-shadow:0 18px 50px #1720330d}.topbar h1{letter-spacing:-.04em}.status-pill{box-shadow:0 10px 24px #3857f61c}.panel,.table-card,.feature-card,.metric,.detail-hero,.profile-hero{border-radius:16px!important;border-color:#e8ecf5!important;box-shadow:0 20px 60px #1720330d!important}button,.primary,.secondary,.ghost,.mini{border-radius:11px!important}.primary{background:linear-gradient(135deg,#3857f6,#6d5dfc)!important;box-shadow:0 12px 24px #3857f626}.secondary{background:#eef2ff!important}.cx-hero-banner{position:relative;overflow:hidden;background:linear-gradient(135deg,#172033,#3857f6 58%,#8b5cf6);border-radius:22px;color:#fff;padding:28px;margin-bottom:18px;box-shadow:0 24px 80px #3857f633}.cx-hero-banner:after{content:"";position:absolute;right:-70px;top:-80px;width:260px;height:260px;border-radius:50%;background:#ffffff22}.cx-hero-banner h2{font-size:30px;margin:0 0 8px;letter-spacing:-.04em}.cx-hero-banner p{max-width:760px;color:#e5eaff;margin:0}.cx-rule-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:18px}.cx-rule-tile{background:#ffffff17;border:1px solid #ffffff30;border-radius:16px;padding:15px}.cx-rule-tile b{display:block;color:#fff;font-size:15px}.cx-rule-tile span{display:block;color:#dbe4ff;font-size:12px;margin-top:4px}.cx-info-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin:18px 0}.cx-info-card{background:#fff;border:1px solid #e8ecf5;border-radius:16px;padding:18px;box-shadow:0 16px 45px #1720330b}.cx-info-card h3{margin:0 0 6px}.cx-info-card strong{font-size:24px}.cx-ledger{background:#fff;border:1px solid #e8ecf5;border-radius:16px;box-shadow:0 16px 45px #1720330b;overflow:hidden;margin-top:18px}.cx-ledger h3{padding:18px;margin:0}.cx-ledger table{width:100%}.cx-status-frozen{color:#a16207;font-weight:900}.cx-status-released{color:#15803d;font-weight:900}.cx-status-refunded{color:#b42318;font-weight:900}.cx-economy-note{display:grid;grid-template-columns:42px minmax(0,1fr);gap:12px;align-items:start;background:#f5f7ff;border:1px solid #dfe6ff;border-radius:14px;padding:14px;margin-top:14px}.cx-economy-note b{display:block;color:#172033}.cx-economy-note span{color:#667085;font-size:13px}.cx-pill-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.cx-pill{border-radius:999px;background:#eef2ff;color:#2b41c3;font-weight:800;font-size:12px;padding:7px 10px}.cx-payment-card.sticky{position:sticky;top:18px}.cx-plan.active{box-shadow:0 18px 40px #3857f61f}.cx-method.active{box-shadow:0 18px 40px #3857f61a}.cx-qrcode{width:154px;height:154px;margin:16px auto;background:conic-gradient(from 90deg,#111827 0 25%,#fff 0 50%,#111827 0 75%,#fff 0);background-size:22px 22px;border:12px solid #fff;box-shadow:0 0 0 1px #dce2ef,0 14px 34px #1720331a}
    @media(max-width:980px){.cx-course-grid,.cx-fields,.cx-series-summary,.cx-topup-hero,.cx-plan-grid,.cx-rule-grid,.cx-info-grid{grid-template-columns:1fr}.cx-series-row{grid-template-columns:28px 26px 1fr 32px}.cx-series-row input[type=datetime-local]{grid-column:3}.cx-session{grid-template-columns:30px 1fr}.cx-session-time{grid-column:2;text-align:left}.cx-progress{min-width:110px}.cx-wallet-cta{align-items:flex-start;flex-direction:column}.cx-payment-card.sticky{position:static}}
  `;
  document.head.appendChild(Object.assign(document.createElement("style"), { textContent: styles }));

  const routePath = () => location.hash.startsWith("#/") ? location.hash.slice(1) : location.pathname;
  const navigate = path => { location.hash = path; };
  const balance = () => Number(localStorage.getItem(BALANCE_KEY) || "320");
  const setBalance = value => {
    localStorage.setItem(BALANCE_KEY, String(value));
    document.querySelectorAll("[data-point-balance]").forEach(el => el.textContent = `${value} points`);
    const pill = [...document.querySelectorAll(".status-pill")].find(el => el.textContent.includes("points"));
    if (pill) pill.innerHTML = pill.innerHTML.replace(/\d+\s+points/, `${value} points`);
  };
  const orders = () => { try { return JSON.parse(localStorage.getItem(POINT_ORDERS_KEY) || "[]"); } catch { return []; } };
  const saveOrder = order => localStorage.setItem(POINT_ORDERS_KEY, JSON.stringify([order, ...orders()].slice(0, 8)));
  const pct = c => Math.min(100, Math.round((c.watched || 0) / (c.total || 1) * 100));
  const downloaded = id => localStorage.getItem(`colearnx-downloaded-${id}`) === "true";
  const courseIdFromText = text => ids.find(id => text.includes(courses[id].title));
  const dateText = iso => new Date(iso).toLocaleString("en-SG", { dateStyle: "medium", timeStyle: "short" });
  const startDate = c => new Date(c.startsAt);
  const liveEndDate = c => new Date(startDate(c).getTime() + (c.total || 0) * 60000);
  const onlineLearningStatus = c => {
    if (DEMO_NOW < startDate(c)) return "Upcoming";
    if (c.replay && DEMO_NOW >= liveEndDate(c) && pct(c) < 100) return "Replay available";
    if (pct(c) >= 100) return "Watched";
    return "Watching";
  };
  const learningCta = c => c.mode === "online" && onlineLearningStatus(c) === "Upcoming" ? "View schedule" : c.watched ? "Continue" : "Start";
  const platformRulesHero = (title = "Platform points economy") => `<section class="cx-hero-banner"><h2>${title}</h2><p>External payment is used only to buy points. Course and content purchases use platform points; points are permanent, non-withdrawable, and can only be spent inside CoLearnX.</p><div class="cx-rule-grid"><div class="cx-rule-tile"><b>100% to seller</b><span>Seller receives the full point price, no platform commission in points.</span></div><div class="cx-rule-tile"><b>Frozen first</b><span>Seller points stay frozen during refund/first-access checks.</span></div><div class="cx-rule-tile"><b>Release trigger</b><span>First valid course/content access releases frozen seller points.</span></div><div class="cx-rule-tile"><b>Refund path</b><span>Approved refunds return platform points to the buyer wallet.</span></div></div></section>`;
  const sellerSettlement = (c, state = "Frozen") => `<div class="cx-economy-note"><div class="cx-badge ${state === "Released" ? "owned" : state === "Refunded" ? "danger" : "series"}">${state}</div><div><b>Seller receives 100% of ${c.price} points, but settlement is frozen first.</b><span>Points are released after first valid access, or returned to the buyer if refund is approved. Points cannot be withdrawn as cash.</span></div></div>`;
  const ledgerTable = (title, rows) => `<section class="cx-ledger"><h3>${title}</h3><table><thead><tr><th>Date / ID</th><th>Party</th><th>Item / Case</th><th>Points / Status</th><th>Trigger / Action</th></tr></thead><tbody>${(rows.length ? rows : [{ id: "—", channel: "No matching record", settlement: "No ledger event yet", status: "—", action: "Waiting for user action" }]).map(r => `<tr><td>${r.date || r.id}</td><td>${r.seller || r.channel || "Platform"}</td><td>${r.item || r.case || r.settlement}</td><td class="${r.state === "Frozen" ? "cx-status-frozen" : r.state === "Released" ? "cx-status-released" : r.state === "Refunded" ? "cx-status-refunded" : ""}">${r.points ? `${r.points} pts · ${r.state}` : r.status || "Review"}</td><td>${r.trigger || r.action || r.settlement}</td></tr>`).join("")}</tbody></table></section>`;

  function showToast(message) {
    document.querySelector(".cx-toast")?.remove();
    const el = document.createElement("div");
    el.className = "cx-toast";
    el.textContent = message;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2600);
  }

  function modal(title, body, confirmLabel, onConfirm) {
    const wrap = document.createElement("div");
    wrap.className = "cx-modal-backdrop";
    wrap.innerHTML = `<section class="cx-modal" role="dialog" aria-modal="true"><h2>${title}</h2>${body}<div class="actions"><button class="secondary" data-cancel>Cancel</button>${confirmLabel ? `<button class="primary" data-confirm>${confirmLabel}</button>` : ""}</div></section>`;
    document.body.appendChild(wrap);
    wrap.querySelector("[data-cancel]").onclick = () => wrap.remove();
    if (confirmLabel) wrap.querySelector("[data-confirm]").onclick = () => { onConfirm?.(); wrap.remove(); };
  }

  function refundInfo(id) {
    const c = courses[id];
    if (c.mode === "offline") {
      const limit = Math.floor(c.total / 5);
      const isDownloaded = downloaded(id);
      const eligible = !isDownloaded && (c.watched || 0) <= limit;
      return {
        eligible,
        title: isDownloaded ? "Not refundable: downloaded locally" : eligible ? "Refund available" : "Refund unavailable",
        detail: isDownloaded ? "Local download permanently removes refund eligibility." : `Cloud viewing: watched ${c.watched || 0} min. Refund limit is 1/5 of ${c.total} min (${limit} min).`,
        rule: "Offline: refundable only while cloud viewing is at or below 1/5 of total duration. No refund after local download."
      };
    }
    const deadline = new Date(startDate(c).getTime() - 3 * DAY);
    const eligible = DEMO_NOW < deadline;
    return {
      eligible,
      title: eligible ? "Refund available" : "Refund window closed",
      deadline,
      detail: `Course starts ${dateText(c.startsAt)}. Refund deadline: ${dateText(deadline)}.`,
      rule: "Online: refundable until three days before the course starts."
    };
  }

  function formatLabel(c) {
    if (c.mode === "online") return `Online / Live${c.replay ? " + Replay" : ""}`;
    return `Offline / ${c.access === "cloud" ? "Cloud viewing" : "Local download"}`;
  }
  const badgeClass = c => c.mode === "offline" ? "offline" : c.replay ? "replay" : "live";
  const progressMarkup = c => { const p = pct(c); return `<div class="cx-progress"><div class="cx-progress-head"><span>Watched ${c.watched || 0} / ${c.total} min</span><strong>${p}%</strong></div><div class="cx-track"><span style="width:${p}%"></span></div></div>`; };
  const purchaseProgressMarkup = c => c.mode === "online" ? `<div class="cx-date-note"><strong>${onlineLearningStatus(c)}</strong><span>Starts ${dateText(c.startsAt)}</span><span>${c.replay ? "Replay opens after live ends" : "No replay after live"}</span></div>` : progressMarkup(c);
  const onlineStatusMarkup = (c, info) => `<div class="cx-status-list"><span><b>${onlineLearningStatus(c)}</b>Learning status</span><span><b>${dateText(c.startsAt)}</b>Live start</span><span><b>${dateText(info.deadline)}</b>Refund deadline</span><span><b>${c.replay ? "Replay opens after live ends" : "No replay"}</b>Replay setting</span></div>`;
  const purchaseRefundMarkup = (id, c, info) => `<div class="cx-refund-note"><span class="cx-badge ${info.eligible ? "owned" : "danger"}">${info.eligible ? "Eligible" : "Not eligible"}</span><small>${c.mode === "online" ? `Before ${dateText(info.deadline)}` : downloaded(id) ? "Downloaded locally" : `Cloud limit: ${Math.floor(c.total / 5)} min`}</small></div>`;

  function courseCard(id) {
    const c = courses[id], next = c.sessions[0];
    return `<article class="cx-course-card" data-course-id="${id}" data-mode="${c.mode}" data-delivery="${c.mode === "online" ? `live${c.replay ? " replay" : ""}` : "cloud download"}" data-status="${c.purchased ? "purchased" : "available"}" data-structure="${c.structure}">
      <div class="cx-cover ${c.category.toLowerCase()}"><span class="cx-cover-mark">${c.category.slice(0,2).toUpperCase()}</span><span class="cx-badge ${badgeClass(c)}">${formatLabel(c)}</span></div>
      <div class="cx-card-body"><h3>${c.title}</h3><span class="cx-trainer">${c.trainer} &middot; ${c.category}</span>
      <div class="cx-card-meta"><span class="cx-meta">${icon("clock")} ${c.duration} total</span><span class="cx-meta">${icon(c.structure === "series" ? "users" : "calendar")} ${c.structure === "series" ? `${c.sessions.length}-class series` : "Single class"}</span><span class="cx-meta">${icon("calendar")} ${next.date}</span><span class="cx-meta">${icon(c.mode === "offline" ? "download" : "play")} ${c.mode === "offline" ? "Cloud or local" : c.replay ? "Live + replay" : "Live only"}</span></div>
      <div class="cx-pill-row"><span class="cx-pill">Pay with points only</span><span class="cx-pill">Seller gets 100%</span><span class="cx-pill">Frozen until access</span></div>
      <div class="cx-card-footer">${c.purchased ? `<div><span class="cx-badge owned">${icon("check",13)} Purchased</span></div>` : `<span class="cx-price">${c.price} points</span>`}<button class="${c.purchased ? "secondary" : "primary"}" data-open-course>${c.purchased ? learningCta(c) : "View & purchase"}</button></div></div></article>`;
  }

  function enhanceMarketplace(main) {
    const heading = [...main.querySelectorAll("h2")].find(el => el.textContent.includes("Browse Trainer Courses")) || main.querySelector(".toolbar");
    const old = [...main.querySelectorAll(".table-card")].find(el => el.querySelector("table"));
    if (!old || old.dataset.cxEnhanced) return;
    old.dataset.cxEnhanced = "true";
    old.style.display = "none";
    const toolbar = document.createElement("section");
    toolbar.className = "cx-toolbar";
    toolbar.innerHTML = `<div class="cx-filter-stack">
      <div class="cx-filter-block"><label>Course mode</label><div class="cx-filter-group" data-group="mode"><button class="cx-filter active" data-value="all">All</button><button class="cx-filter" data-value="online">Online</button><button class="cx-filter" data-value="offline">Offline</button></div></div>
      <div class="cx-filter-block"><label>Format / access</label><div class="cx-filter-group" data-group="delivery"><button class="cx-filter active" data-value="all">All</button><button class="cx-filter" data-value="live">Live</button><button class="cx-filter" data-value="replay">With replay</button><button class="cx-filter" data-value="cloud">Cloud</button><button class="cx-filter" data-value="download">Local download</button></div></div>
      <div class="cx-filter-block"><label>Purchase</label><div class="cx-filter-group" data-group="status"><button class="cx-filter active" data-value="all">All</button><button class="cx-filter" data-value="purchased">Purchased</button><button class="cx-filter" data-value="available">Available</button></div></div>
      <div class="cx-filter-block"><label>Structure</label><div class="cx-filter-group" data-group="structure"><button class="cx-filter active" data-value="all">All</button><button class="cx-filter" data-value="single">Single</button><button class="cx-filter" data-value="series">Series</button></div></div>
      </div><span class="cx-muted" data-result-count>4 courses</span>`;
    const grid = document.createElement("section");
    grid.className = "cx-course-grid";
    grid.innerHTML = ids.map(courseCard).join("");
    const empty = document.createElement("div");
    empty.className = "cx-empty";
    empty.innerHTML = `<strong>No matching courses</strong><span class="cx-muted">Try clearing one or more filters.</span><br><button class="secondary" data-clear-filters>Clear filters</button>`;
    (heading || old).insertAdjacentHTML("afterend", platformRulesHero("Buy courses and contents with platform points"));
    const hero = (heading || old).nextElementSibling;
    hero.insertAdjacentElement("afterend", toolbar);
    toolbar.insertAdjacentElement("afterend", grid);
    grid.insertAdjacentElement("afterend", empty);
    const applyFilters = () => {
      const selected = {};
      toolbar.querySelectorAll("[data-group]").forEach(group => selected[group.dataset.group] = group.querySelector(".active").dataset.value);
      let count = 0;
      grid.querySelectorAll(".cx-course-card").forEach(card => {
        const show = Object.entries(selected).every(([key,val]) => val === "all" || card.dataset[key].split(" ").includes(val));
        card.hidden = !show;
        if (show) count++;
      });
      toolbar.querySelector("[data-result-count]").textContent = `${count} course${count === 1 ? "" : "s"}`;
      empty.classList.toggle("show", count === 0);
    };
    toolbar.onclick = event => {
      const button = event.target.closest(".cx-filter");
      if (!button) return;
      const group = button.closest("[data-group]");
      group.querySelectorAll(".cx-filter").forEach(el => el.classList.toggle("active", el === button));
      applyFilters();
    };
    grid.onclick = event => {
      const card = event.target.closest("[data-course-id]");
      if (card) navigate(`/courses/${card.dataset.courseId}`);
    };
    empty.querySelector("[data-clear-filters]").onclick = () => { toolbar.querySelectorAll("[data-group]").forEach(group => group.querySelectorAll(".cx-filter").forEach((el,i) => el.classList.toggle("active", i === 0))); applyFilters(); };
  }

  function enhanceContents(main) {
    if (!main || main.dataset.cxContentEnhanced) return;
    main.dataset.cxContentEnhanced = "true";
    const anchor = main.querySelector(".toolbar") || main.querySelector(".table-card") || main.querySelector(".topbar");
    anchor?.insertAdjacentHTML("afterend", `${platformRulesHero("Content purchases use platform points")}<section class="cx-info-grid"><div class="cx-info-card"><h3>Buyer payment</h3><strong>Points only</strong><p class="cx-muted">External payment is never used directly for content checkout.</p></div><div class="cx-info-card"><h3>Creator settlement</h3><strong>100%</strong><p class="cx-muted">Creator receives the full point price after release.</p></div><div class="cx-info-card"><h3>Release trigger</h3><strong>First access</strong><p class="cx-muted">Opening the file/video releases frozen creator points.</p></div></section>${ledgerTable("Creator content settlement examples", sellerLedger.filter(r => r.seller?.includes("Creator")))}`);
  }

  function scheduleMarkup(c) {
    return `<section class="panel cx-schedule"><div class="cx-schedule-head"><h3>${c.structure === "series" ? "Complete series timetable" : "Class schedule"}</h3><span class="cx-badge ${c.structure === "series" ? "series" : ""}">${c.structure === "series" ? `${c.sessions.length}-class series` : "Single class"}</span></div>
      ${c.structure === "series" ? `<div class="cx-series-summary"><div class="cx-series-stat"><strong>${c.sessions.length}</strong><span>Total classes</span></div><div class="cx-series-stat"><strong>${c.duration}</strong><span>Total duration</span></div><div class="cx-series-stat"><strong>Full bundle</strong><span>Purchased together</span></div></div>` : ""}
      ${c.sessions.map((s,i) => `<div class="cx-session">${icon("calendar",18)}<div><strong>${c.structure === "series" ? `Class ${i+1}: ` : ""}${s.topic}</strong><span>${s.location} &middot; ${s.duration}${s.status ? ` &middot; ${s.status}` : ""}</span></div><div class="cx-session-time"><b>${s.date}</b><br>${s.time}</div></div>`).join("")}</section>`;
  }
  function ruleMarkup(id) {
    const c = courses[id], info = refundInfo(id);
    const settlement = `<div class="cx-economy-note"><div class="cx-badge series">Settlement</div><div><b>Buyer pays ${c.price} platform points. Seller receives 100% points after release.</b><span>Points are frozen first. They are released after first valid access, or returned to buyer if refund is approved. Points are permanent and non-withdrawable.</span></div></div>`;
    if (!c.purchased) return `<section class="cx-rule" data-refund-rule><h3>Refund policy before purchase</h3><p>${info.rule}</p>${settlement}${c.mode === "offline" ? '<div class="cx-warning">Downloading the course to a local device removes refund eligibility.</div>' : `<p class="cx-muted">Current refund deadline: ${dateText(info.deadline)}</p>`}</section>`;
    return `<section class="cx-rule ${info.eligible ? "eligible" : "ineligible"}" data-refund-rule><h3>${info.title}</h3><p>${info.detail}</p><p class="cx-muted">${info.rule}</p>${sellerSettlement(c, "Frozen")}</section>`;
  }

  function enhanceDetail(main) {
    const id = routePath().split("/").filter(Boolean)[1], c = courses[id], hero = main.querySelector(".detail-hero");
    if (!c || !hero || hero.dataset.cxEnhanced === id) return;
    main.querySelectorAll(".cx-schedule,.cx-rule").forEach(el => el.remove());
    hero.dataset.cxEnhanced = id;
    const eyebrow = hero.querySelector(".eyebrow");
    if (eyebrow) eyebrow.innerHTML = `${c.category} &middot; <span class="cx-badge ${badgeClass(c)}">${formatLabel(c)}</span>`;
    const priceBox = hero.querySelector(".price-box");
    if (c.purchased && priceBox) {
      const info = refundInfo(id);
      priceBox.classList.add("cx-owned-box");
      priceBox.innerHTML = c.mode === "online"
        ? `<span class="cx-badge owned">${icon("check",13)} Purchased</span><strong>${onlineLearningStatus(c)}</strong>${onlineStatusMarkup(c, info)}`
        : `<span class="cx-badge owned">${icon("check",13)} Purchased</span><strong>Ready to learn</strong><div class="cx-progress-card">${progressMarkup(c)}</div>`;
    }
    [...main.querySelectorAll(".grid.two .panel")].find(p => p.querySelector("h3")?.textContent === "Refund Rules")?.remove();
    const actions = main.querySelector(".actions");
    actions?.insertAdjacentHTML("beforebegin", `${scheduleMarkup(c)}${ruleMarkup(id)}${ledgerTable("Seller point settlement preview", sellerLedger.filter(r => r.item === c.title || r.item.includes(c.title.split(" ")[0])).slice(0, 2))}`);
    if (actions && c.purchased) {
      actions.innerHTML = `<button class="primary" data-learn-now>${icon("play")} ${learningCta(c)}</button>${c.mode === "offline" ? `<button class="secondary" data-download ${downloaded(id) ? "disabled" : ""}>${icon("download")} ${downloaded(id) ? "Downloaded locally" : "Download to device"}</button>` : ""}<button class="ghost" data-refund ${refundInfo(id).eligible ? "" : "disabled"}>Request refund</button>`;
      actions.querySelector("[data-learn-now]").onclick = () => showToast(c.mode === "online" && onlineLearningStatus(c) === "Upcoming" ? "Schedule opened. Learning starts after the live session begins." : "Learning opened at your last position");
      actions.querySelector("[data-refund]").onclick = () => navigate(`/refund/${id}`);
      const dl = actions.querySelector("[data-download]");
      if (dl && !dl.disabled) dl.onclick = () => modal("Download to this device?", `<div class="cx-warning"><b>Important:</b><span>After the course is downloaded locally, it cannot be refunded. This action cannot be undone.</span></div><p>The cloud version will remain available in My Purchases.</p>`, "Download and waive refund", () => {
        localStorage.setItem(`colearnx-downloaded-${id}`, "true");
        dl.disabled = true;
        dl.innerHTML = `${icon("check")} Downloaded locally`;
        const rule = main.querySelector("[data-refund-rule]");
        if (rule) rule.outerHTML = ruleMarkup(id);
        actions.querySelector("[data-refund]").disabled = true;
        showToast("Download started. Refund eligibility removed.");
      });
    } else if (actions) {
      [...actions.querySelectorAll("button")].filter(button => button.textContent.includes("Refund")).forEach(button => button.remove());
    }
  }

  function enhancePurchases(main) {
    main.classList.add("cx-purchases-page");
    const table = [...main.querySelectorAll(".table-card")].find(el => el.querySelector("h3")?.textContent === "Courses");
    if (!table || table.dataset.cxEnhanced) return;
    table.dataset.cxEnhanced = "true";
    table.querySelector("thead tr").innerHTML = "<th>Course</th><th>Format</th><th>Progress / Start</th><th>Refund</th><th>Seller points</th><th></th>";
    table.querySelectorAll("tbody tr").forEach(row => {
      const id = courseIdFromText(row.textContent);
      if (!id) return;
      const c = courses[id];
      if (!c.purchased) { row.remove(); return; }
      const info = refundInfo(id);
      const status = c.mode === "online" ? onlineLearningStatus(c) : !c.watched ? "Unwatched" : pct(c) >= 100 ? "Watched" : "Watching";
      row.dataset.learningStatus = status;
      row.innerHTML = `<td><strong>${c.title}</strong><br><span class="cx-badge owned">Purchased</span><br><span class="cx-muted">${status}</span></td><td><span class="cx-badge ${badgeClass(c)}">${formatLabel(c)}</span></td><td>${purchaseProgressMarkup(c)}</td><td>${purchaseRefundMarkup(id, c, info)}</td><td><span class="cx-badge series">Frozen</span><br><span class="cx-muted">${c.price} pts · 100% to seller after first access</span></td><td><button class="primary mini" data-open>${learningCta(c)}</button></td>`;
      row.querySelector("[data-open]").onclick = () => navigate(`/courses/${id}`);
    });
    const empty = document.createElement("div");
    empty.className = "cx-empty";
    empty.innerHTML = `<strong>No courses in this state</strong><span class="cx-muted">Your courses will appear here when their learning status changes.</span>`;
    table.appendChild(empty);
    const tabs = main.querySelector(".tabs");
    if (tabs) {
      tabs.innerHTML = ["All","Upcoming","Watching","Replay available","Watched","Refunded"].map((label,i)=>`<button class="${i===0?"active":""}">${label}</button>`).join("");
      const buttons = [...tabs.querySelectorAll("button")];
      const apply = label => {
        let count = 0;
        table.querySelectorAll("tbody tr").forEach(row => {
          const show = label === "All" || row.dataset.learningStatus === label;
          row.hidden = !show;
          if (show) count++;
        });
        empty.classList.toggle("show", count === 0);
        buttons.forEach(button => button.classList.toggle("active", button.textContent.trim() === label));
      };
      tabs.onclick = event => { const button = event.target.closest("button"); if (button) apply(button.textContent.trim()); };
      apply("All");
    }
    table.insertAdjacentHTML("beforebegin", `<section class="cx-hero-banner"><h2>Purchase ledger</h2><p>Course and content purchases never use external payment directly. The buyer spends platform points, the seller receives 100% of the point price, and those seller points stay frozen until first valid access or refund expiry.</p></section>`);
    table.insertAdjacentHTML("afterend", ledgerTable("Seller frozen / release ledger", sellerLedger));
  }

  function enhanceRefund(main) {
    const id = routePath().split("/").filter(Boolean)[1], c = courses[id];
    if (!c || main.querySelector("[data-cx-refund]")) return;
    const info = refundInfo(id);
    const context = c.mode === "online"
      ? `<p><b>${c.title}</b></p><p>${formatLabel(c)}</p><p>Live start: ${dateText(c.startsAt)}</p><p>Replay: ${c.replay ? "Available after live ends" : "No replay"}</p><p class="cx-muted">Online refunds do not depend on watch time.</p>`
      : `<p><b>${c.title}</b></p><p>${formatLabel(c)}</p><p>Cloud watched: ${c.watched || 0} / ${c.total} min</p><p>Refund watch limit: ${Math.floor(c.total / 5)} min</p><p>${downloaded(id) ? "Downloaded locally: yes" : "Downloaded locally: no"}</p>`;
    const grid = main.querySelector(".grid.two");
    if (grid) {
      grid.dataset.cxRefund = "true";
      grid.innerHTML = `<section class="panel"><h3>Course and access</h3>${context}</section><section class="panel"><h3>Refund eligibility</h3><span class="cx-badge ${info.eligible ? "owned" : "danger"}">${info.title}</span><p>${info.detail}</p><p class="cx-muted">${info.rule}</p>${sellerSettlement(c, info.eligible ? "Frozen" : "Released")}</section>`;
    }
    const form = [...main.querySelectorAll(".panel")].find(p => p.querySelector("textarea"));
    if (form) {
      form.insertAdjacentHTML("afterbegin", `<div class="cx-validation ${info.eligible ? "" : "show"}">${info.eligible ? "" : `This request cannot be submitted: ${info.title}.`}</div>`);
      const submit = [...form.querySelectorAll("button")].find(b => b.textContent.includes("Submit"));
      if (submit) { submit.disabled = !info.eligible; submit.textContent = info.eligible ? "Submit refund request" : "Refund unavailable"; }
    }
  }

  function rowsMarkup(count) {
    return Array.from({length:count},(_,i)=>`<div class="cx-series-row" draggable="true" data-sort-row><span class="cx-grip" title="Drag to reorder">${icon("grip",18)}</span><b>${i+1}</b><input data-row-title value="Class ${i+1}: ${["Foundations","Guided practice","Final project"][i]||"New class"}" aria-label="class ${i+1} title"><input type="datetime-local" value="2026-07-${String(14+i*2).padStart(2,"0")}T19:00" aria-label="class ${i+1} timing"><button type="button" class="cx-icon-btn" data-remove-row title="Remove">x</button></div>`).join("");
  }
  function onlineMarkup() {
    return `<div class="cx-fields"><div class="cx-field"><label>Delivery method</label><input value="Live online" disabled></div><div class="cx-field"><label>Course start *</label><input data-required type="datetime-local" value="2026-08-03T20:00"></div><div class="cx-field"><label>Timezone *</label><select data-required><option value="Asia/Singapore">Asia/Singapore (GMT+8)</option><option>UTC</option></select></div><div class="cx-field"><label>Total live duration *</label><input data-required value="2 hr" placeholder="e.g. 2 hr"></div><div class="cx-field"><label>Live replay after class *</label><select data-replay><option value="true" ${editorState.hasReplay?"selected":""}>Yes, provide replay after live ends</option><option value="false" ${!editorState.hasReplay?"selected":""}>No replay</option></select></div>${editorState.hasReplay?'<div class="cx-field"><label>Replay availability</label><select><option>Available after trainer publishes replay</option><option>Available automatically after live ends</option><option>Available for 90 days</option></select></div>':""}</div><div class="cx-warning">${icon("play",18)}<span>Online courses are live by default. If replay is enabled, learners can watch the live recording only after the live session has ended.</span></div><div class="cx-economy-note"><div class="cx-badge series">Seller points</div><div><b>Trainer receives 100% of the course point price.</b><span>Points are frozen first, released after first valid access, and cannot be withdrawn as cash.</span></div></div><div class="cx-summary"><span class="cx-badge live">Live</span><span class="cx-badge ${editorState.hasReplay?"replay":"danger"}">${editorState.hasReplay?"Replay enabled":"No replay"}</span><span>Refundable until three days before the scheduled start.</span></div>`;
  }
  function offlineMarkup() {
    const single = editorState.offlineType === "single";
    return `<div class="cx-fields"><div class="cx-field"><label>Course structure *</label><select data-offline-type><option value="single" ${single?"selected":""}>Single class</option><option value="series" ${!single?"selected":""}>Series / course bundle</option></select></div><div class="cx-field"><label>Default access *</label><select data-access><option value="cloud" ${editorState.access==="cloud"?"selected":""}>Cloud viewing</option><option value="download" ${editorState.access==="download"?"selected":""}>Download to local device</option></select></div><div class="cx-field"><label>Venue *</label><input data-required value="CoLearnX Studio A"></div><div class="cx-field"><label>Timezone *</label><select data-required><option>Asia/Singapore (GMT+8)</option><option>UTC</option></select></div></div>${single?'<div class="cx-fields"><div class="cx-field"><label>Class date and time *</label><input data-required type="datetime-local" value="2026-07-12T10:00"></div><div class="cx-field"><label>Duration *</label><input data-required value="45 min"></div></div>':`<div class="cx-section-heading" style="margin-top:18px"><div><h3>Series timetable</h3><p>Drag classes to reorder them. Duplicate dates are checked before publishing.</p></div><span class="cx-badge series">${editorState.sessions} classes</span></div><div class="cx-series-list" data-sort-list>${rowsMarkup(editorState.sessions)}</div><button type="button" class="secondary mini cx-add-session" data-add-session>+ Add class</button>`}<div class="cx-warning">${icon("download",18)}<span>Offline refund rule: cloud viewing is refundable up to 1/5 of total duration. Downloading locally makes the purchase non-refundable.</span></div><div class="cx-economy-note"><div class="cx-badge series">Seller points</div><div><b>Trainer receives 100% points after settlement release.</b><span>Cloud viewing keeps refund checks active; local download removes refund eligibility and releases settlement after policy checks.</span></div></div>`;
  }
  const editorMarkup = () => `<div class="cx-editor-section" data-editor-config><div class="cx-section-heading"><div><h3>Course format and structure</h3><p>Configure delivery, access, timetable and refund behaviour.</p></div><span class="cx-badge">Required</span></div><div class="cx-segmented"><button type="button" class="cx-option ${editorState.mode==="online"?"active":""}" data-mode="online"><strong>Online course</strong><span>Live + optional replay</span></button><button type="button" class="cx-option ${editorState.mode==="offline"?"active":""}" data-mode="offline"><strong>Offline course</strong><span>Cloud viewing or local download</span></button></div>${editorState.mode==="online"?onlineMarkup():offlineMarkup()}</div>`;
  function saveDraft(editor) {
    const d = { title: editor.querySelector('input[placeholder="Course Title"]')?.value, price: editor.querySelector('input[placeholder="Point Price"]')?.value, mode: editorState.mode, hasReplay: editorState.hasReplay, updated: new Date().toISOString() };
    localStorage.setItem(DRAFT_KEY, JSON.stringify(d));
    const status = editor.querySelector("[data-autosave]");
    if (status) status.innerHTML = `${icon("check",13)} Draft autosaved ${new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}`;
  }
  function validateEditor(editor) {
    editor.querySelectorAll(".invalid").forEach(e => e.classList.remove("invalid"));
    const errors = [];
    [[editor.querySelector('input[placeholder="Course Title"]'), "Course title is required"], [editor.querySelector('input[placeholder="Point Price"]'), "Point price is required"], ...Array.from(editor.querySelectorAll("[data-required]")).map(e => [e, "Complete all required scheduling fields"])].forEach(([el,msg]) => {
      if (el && !String(el.value).trim()) { el.classList.add("invalid"); errors.push(msg); }
    });
    if (editorState.mode === "offline" && editorState.offlineType === "series") {
      const values = [...editor.querySelectorAll('[data-sort-row] input[type="datetime-local"]')].map(e => e.value).filter(Boolean);
      if (new Set(values).size !== values.length) errors.push("Series classes cannot use duplicate dates and times");
    }
    const box = editor.querySelector("[data-validation]");
    if (box) { box.textContent = [...new Set(errors)].join(". "); box.classList.toggle("show", errors.length > 0); }
    return errors.length === 0;
  }
  function previewEditor(editor) {
    if (!validateEditor(editor)) return;
    const title = editor.querySelector('input[placeholder="Course Title"]')?.value || "Untitled course", price = editor.querySelector('input[placeholder="Point Price"]')?.value || "0";
    modal("Course preview", `<span class="cx-badge ${editorState.mode==="online"?(editorState.hasReplay?"replay":"live"):"offline"}">${editorState.mode==="online"?`Online / Live${editorState.hasReplay?" + Replay":""}`:`Offline / ${editorState.offlineType}`}</span><div class="cx-preview-list"><p><b>${title}</b></p><p>${price} points</p><p>${editorState.mode==="online"?`Live course${editorState.hasReplay?", replay opens after live ends":", no replay"}`:editorState.offlineType==="series"?`${editorState.sessions} scheduled classes`:"Single scheduled course"}</p><p>Timezone: Asia/Singapore (GMT+8)</p></div><p class="cx-muted">This is how the course configuration will be published.</p>`, null);
  }
  function enhanceEditor(main) {
    const editor = main.querySelector(".panel.editor");
    if (!editor || editor.dataset.cxEnhanced) return;
    editor.dataset.cxEnhanced = "true";
    const capacity = editor.querySelector('input[placeholder="Capacity"]');
    capacity?.insertAdjacentHTML("afterend", `<div class="cx-validation" data-validation></div>${editorMarkup()}`);
    const actions = editor.querySelector(".actions");
    actions?.insertAdjacentHTML("afterbegin", `<button type="button" class="ghost" data-preview>Preview course</button><span class="cx-autosave" data-autosave>Draft autosave ready</span>`);
    const lock = () => editor.querySelectorAll("[data-editor-config] button,[data-editor-config] input,[data-editor-config] select").forEach(el => el.disabled = Boolean(capacity?.disabled));
    const rerender = () => { editor.querySelector("[data-editor-config]").outerHTML = editorMarkup(); lock(); };
    lock();
    let dragRow = null, saveTimer;
    editor.addEventListener("input", () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => saveDraft(editor), 350); });
    editor.addEventListener("change", e => {
      if (e.target.matches("[data-replay]")) editorState.hasReplay = e.target.value === "true";
      if (e.target.matches("[data-offline-type]")) editorState.offlineType = e.target.value;
      if (e.target.matches("[data-access]")) editorState.access = e.target.value;
      if (e.target.matches("[data-replay],[data-offline-type]")) rerender();
      saveDraft(editor);
    });
    editor.addEventListener("dragstart", e => { dragRow = e.target.closest("[data-sort-row]"); dragRow?.classList.add("dragging"); });
    editor.addEventListener("dragover", e => { const over = e.target.closest("[data-sort-row]"); if (dragRow && over && over !== dragRow) { e.preventDefault(); over.parentNode.insertBefore(dragRow, over); } });
    editor.addEventListener("dragend", () => { dragRow?.classList.remove("dragging"); dragRow = null; saveDraft(editor); });
    editor.addEventListener("click", e => {
      const mode = e.target.closest("[data-mode]");
      if (mode) { editorState.mode = mode.dataset.mode; rerender(); return; }
      if (e.target.closest("[data-add-session]")) { editorState.sessions++; rerender(); return; }
      const remove = e.target.closest("[data-remove-row]");
      if (remove) { const list = remove.closest("[data-sort-list]"); remove.closest("[data-sort-row]").remove(); [...list.children].forEach((row,i) => row.querySelector("b").textContent = i+1); return; }
      if (e.target.closest("[data-preview]")) { previewEditor(editor); return; }
      const publish = e.target.closest("button.primary");
      if (publish && !publish.disabled) {
        if (!validateEditor(editor)) { e.preventDefault(); e.stopPropagation(); showToast("Please fix the highlighted fields before publishing"); }
        else { localStorage.removeItem(DRAFT_KEY); showToast("Course published with schedule and refund settings"); }
      }
    });
  }

  function appShell(content, title = "Buy Points", active = "buy-points") {
    const nav = [
      ["home", "Home", "#/home"], ["courses", "Courses", "#/courses"], ["contents", "Contents", "#/contents"], ["cart", "Cart", "#/cart"],
      ["purchases", "My Purchases", "#/purchases"], ["wallet", "Points Wallet", "#/wallet"], ["buy-points", "Buy Points", "#/buy-points"], ["role", "Role Application", "#/role-application"]
    ].map(([key,label,href]) => `<a href="${href}" class="${key === active ? "active" : ""}" ${key === "buy-points" ? "data-buy-points-nav" : ""}>${label}</a>`).join("");
    document.getElementById("root").innerHTML = `<div class="app-shell"><aside class="sidebar"><div class="brand">Co<span>LearnX</span></div><nav>${nav}</nav><div class="role-switcher"><label>Demo role</label><select><option>Member</option><option>Trainer</option><option>Creator</option><option>Admin</option></select></div></aside><main><div class="topbar"><div><span class="eyebrow">MODERN LEARNING MARKETPLACE</span><h1>${title}</h1></div><div class="status-pill">◎ <span data-point-balance>${balance()} points</span> · Member</div></div>${content}</main></div>`;
  }
  function fixStatusPill() {
    const pill = document.querySelector(".status-pill");
    if (pill) pill.innerHTML = `◎ <span data-point-balance>${balance()} points</span> &middot; Member`;
  }
  function buyPointsPage() {
    const params = new URLSearchParams((location.hash.split("?")[1] || ""));
    const step = params.get("step") || "plan";
    document.getElementById("root").dataset.cxCustomRoute = `buy-points-${step}`;
    const selectedId = localStorage.getItem("colearnx-selected-plan") || "popular";
    const selected = pointPlans.find(p => p.id === selectedId) || pointPlans[1];
    const method = localStorage.getItem("colearnx-payment-method") || "card";
    const stepper = `<div class="cx-stepper"><div class="cx-step ${step==="plan"?"active":"done"}"><b>1</b>Select package</div><div class="cx-step ${step==="method"?"active":step==="payment"?"done":""}"><b>2</b>Payment method</div><div class="cx-step ${step==="payment"?"active":""}"><b>3</b>Payment details</div></div>`;
    const summary = `<aside class="cx-payment-card"><h3>Order summary</h3><div class="cx-summary-row"><span>Current balance</span><b>${balance()} pts</b></div><div class="cx-summary-row"><span>Selected package</span><b>${selected.points + selected.bonus} pts</b></div><div class="cx-summary-row"><span>Bonus points</span><b>${selected.bonus} pts</b></div><div class="cx-summary-row total"><span>Total</span><b>S$${selected.price.toFixed(2)}</b></div><div class="cx-safe">Demo checkout only. No real payment is processed.</div></aside>`;
    const planStep = `<div class="cx-topup-card"><span class="cx-badge">Step 1</span><h2>Select a points package</h2><p class="cx-muted">Choose how many points you want to add. Points can be used for courses, contents and future purchases.</p><div class="cx-plan-grid">${pointPlans.map(p => `<button class="cx-plan ${p.id===selected.id?"active":""}" data-plan="${p.id}"><span class="cx-badge">${p.tag}</span><strong>${p.points+p.bonus}</strong><small>${p.points} points${p.bonus?` + ${p.bonus} bonus`:""}</small><div class="price">S$${p.price.toFixed(2)}</div></button>`).join("")}</div><div class="actions"><button class="primary" data-next-method>Continue to payment method</button><button class="secondary" data-back-wallet>Back to wallet</button></div></div>`;
    const methodStep = `<div class="cx-topup-card"><span class="cx-badge">Step 2</span><h2>Choose payment method</h2><p class="cx-muted">Select how the user wants to pay before entering payment details.</p><div class="cx-pay-methods"><label class="cx-method ${method==="card"?"active":""}" data-method="card"><span><strong>Credit / Debit Card</strong><small>Visa, Mastercard, Amex</small></span><input type="radio" name="method" ${method==="card"?"checked":""}></label><label class="cx-method ${method==="paynow"?"active":""}" data-method="paynow"><span><strong>PayNow</strong><small>Show QR code on the next page</small></span><input type="radio" name="method" ${method==="paynow"?"checked":""}></label><label class="cx-method ${method==="wallet"?"active":""}" data-method="wallet"><span><strong>Apple Pay / Google Pay</strong><small>Fast wallet checkout</small></span><input type="radio" name="method" ${method==="wallet"?"checked":""}></label></div><div class="actions"><button class="secondary" data-back-plan>Back</button><button class="primary" data-next-payment>Continue to payment details</button></div></div>`;
    const detail = method === "paynow" ? `<div class="cx-safe" style="text-align:center"><strong>PayNow QR Preview</strong><p>Scan this QR in the real product. In this prototype, click Confirm payment to complete the flow.</p><div style="width:150px;height:150px;margin:16px auto;background:repeating-linear-gradient(45deg,#172033 0 8px,#fff 8px 16px);border:10px solid #fff;box-shadow:0 0 0 1px #dce2ef"></div></div>` : method === "wallet" ? `<div class="cx-safe"><strong>Wallet payment selected</strong><p>Apple Pay / Google Pay confirmation would open here in production.</p></div>` : `<div class="cx-payment-form"><label>Cardholder name<input placeholder="Name on card" value="Demo User"></label><label>Card number<input placeholder="1234 5678 9012 3456" value="4242 4242 4242 4242"></label><div class="cx-form-two"><label>Expiry<input placeholder="MM/YY" value="12/29"></label><label>CVV<input placeholder="123" value="123"></label></div></div>`;
    const paymentStep = `<div class="cx-topup-card"><span class="cx-badge">Step 3</span><h2>Enter payment details</h2><p class="cx-muted">Review the package and complete the selected payment method.</p><p><span class="cx-badge">${method === "paynow" ? "PayNow" : method === "wallet" ? "Apple Pay / Google Pay" : "Credit / Debit Card"}</span></p>${detail}<div class="actions"><button class="secondary" data-back-method>Back</button><button class="primary" data-pay>Confirm payment · S$${selected.price.toFixed(2)}</button></div></div>`;
    const summary2 = `<aside class="cx-payment-card sticky"><h3>Order summary</h3><div class="cx-summary-row"><span>Current balance</span><b>${balance()} pts</b></div><div class="cx-summary-row"><span>Selected package</span><b>${selected.points + selected.bonus} pts</b></div><div class="cx-summary-row"><span>Bonus points</span><b>${selected.bonus} pts</b></div><div class="cx-summary-row total"><span>Total external payment</span><b>S$${selected.price.toFixed(2)}</b></div><div class="cx-economy-note"><div class="cx-badge live">Rule</div><div><b>External payment only buys points.</b><span>Courses and contents are purchased later with platform points. Points never expire and cannot be withdrawn.</span></div></div></aside>`;
    const planStep2 = `<div class="cx-topup-card"><span class="cx-badge">Step 1</span><h2>Select a points package</h2><p class="cx-muted">Choose how many points you want to add. Points are permanent, non-withdrawable, and platform-only.</p><div class="cx-plan-grid">${pointPlans.map(p => `<button class="cx-plan ${p.id===selected.id?"active":""}" data-plan="${p.id}"><span class="cx-badge">${p.tag}</span><strong>${p.points+p.bonus}</strong><small>${p.points} points${p.bonus?` + ${p.bonus} bonus`:""}</small><div class="price">S$${p.price.toFixed(2)}</div></button>`).join("")}</div><div class="cx-info-grid"><div class="cx-info-card"><h3>Permanent</h3><p class="cx-muted">No expiry date for point balance.</p></div><div class="cx-info-card"><h3>No withdrawal</h3><p class="cx-muted">Points cannot be cashed out.</p></div><div class="cx-info-card"><h3>Platform use only</h3><p class="cx-muted">Spend only on Course / Content.</p></div></div><div class="actions"><button class="primary" data-next-method>Continue to payment method</button><button class="secondary" data-back-wallet>Back to wallet</button></div></div>`;
    const detail2 = method === "paynow" ? `<div class="cx-safe" style="text-align:center"><strong>PayNow QR Preview</strong><p>Scan this QR in the real product. In this prototype, click Confirm payment to complete the flow.</p><div class="cx-qrcode"></div></div>` : method === "wallet" ? `<div class="cx-safe"><strong>Wallet payment selected</strong><p>Apple Pay / Google Pay confirmation would open here in production.</p></div>` : detail;
    const paymentStep2 = `<div class="cx-topup-card"><span class="cx-badge">Step 3</span><h2>Enter payment details</h2><p class="cx-muted">Successful external payment creates a top-up order and payment record before points are issued.</p><p><span class="cx-badge">${method === "paynow" ? "PayNow" : method === "wallet" ? "Apple Pay / Google Pay" : "Credit / Debit Card"}</span></p>${detail2}<div class="actions"><button class="secondary" data-back-method>Back</button><button class="primary" data-pay>Confirm payment &middot; S$${selected.price.toFixed(2)}</button></div></div>`;
    appShell(`${platformRulesHero("Buy points with external payment")}${stepper}<section class="cx-topup-hero">${step === "method" ? methodStep : step === "payment" ? paymentStep2 : planStep2}${summary2}</section>${step === "method" ? ledgerTable("Available external payment channels", paymentChannels) : ""}${step === "payment" ? ledgerTable("Abnormal payment / refund handling", abnormalRefunds) : ""}`, step === "plan" ? "Buy Points" : step === "method" ? "Choose Payment Method" : "Payment Details", "buy-points");
    fixStatusPill();
    document.querySelectorAll("[data-plan]").forEach(btn => btn.onclick = () => { localStorage.setItem("colearnx-selected-plan", btn.dataset.plan); document.getElementById("root").dataset.cxCustomRoute = ""; buyPointsPage(); });
    document.querySelectorAll(".cx-method").forEach(label => label.onclick = () => { document.querySelectorAll(".cx-method").forEach(el => el.classList.toggle("active", el === label)); label.querySelector("input").checked = true; });
    document.querySelectorAll("[data-method]").forEach(el => el.onclick = () => { localStorage.setItem("colearnx-payment-method", el.dataset.method); document.getElementById("root").dataset.cxCustomRoute = ""; buyPointsPage(); });
    document.querySelector("[data-back-wallet]")?.addEventListener("click", () => navigate("/wallet"));
    document.querySelector("[data-next-method]")?.addEventListener("click", () => navigate("/buy-points?step=method"));
    document.querySelector("[data-back-plan]")?.addEventListener("click", () => navigate("/buy-points?step=plan"));
    document.querySelector("[data-next-payment]")?.addEventListener("click", () => navigate("/buy-points?step=payment"));
    document.querySelector("[data-back-method]")?.addEventListener("click", () => navigate("/buy-points?step=method"));
    document.querySelector("[data-pay]")?.addEventListener("click", () => {
      const plan = pointPlans.find(p => p.id === (localStorage.getItem("colearnx-selected-plan") || "popular")) || pointPlans[1];
      const added = plan.points + plan.bonus, next = balance() + added;
      setBalance(next);
      const order = { id: `PT-${Date.now().toString().slice(-6)}`, date: "13 Jul 2026", item: `${added} points top-up`, amount: `S$${plan.price.toFixed(2)}`, status: "Paid", balance: next };
      saveOrder(order);
      navigate(`/points-success?points=${added}&order=${order.id}`);
    });
  }
  function successPage() {
    document.getElementById("root").dataset.cxCustomRoute = "points-success";
    const params = new URLSearchParams((location.hash.split("?")[1] || ""));
    appShell(`${platformRulesHero("Top-up completed")}<section class="cx-success-box"><strong>Payment Successful</strong><h2>${params.get("points") || "0"} points added to your wallet</h2><p>Order ID: ${params.get("order") || "PT-000000"}. Your updated balance is <b data-point-balance>${balance()} points</b>.</p><p class="cx-muted">These points are permanent, non-withdrawable, and can only be spent inside CoLearnX.</p><div class="actions" style="justify-content:center"><button class="primary" data-wallet>Go to Points Wallet</button><button class="secondary" data-courses>Browse Courses</button></div></section>`, "Payment Successful");
    fixStatusPill();
    document.querySelector("[data-wallet]").onclick = () => navigate("/wallet");
    document.querySelector("[data-courses]").onclick = () => navigate("/courses");
  }
  function enhanceWallet(main) {
    if (!main || main.dataset.cxWalletEnhanced) return;
    main.dataset.cxWalletEnhanced = "true";
    const topbar = main.querySelector(".topbar");
    const cta = document.createElement("section");
    cta.className = "cx-wallet-cta";
    cta.innerHTML = `<div><h3>Need more points?</h3><p class="cx-muted">Buy points with card, PayNow or wallet payment, then use them across courses and contents.</p></div><button class="primary" data-buy-points>Buy points</button>`;
    topbar?.insertAdjacentElement("afterend", cta);
    cta.querySelector("[data-buy-points]").onclick = () => navigate("/buy-points");
    const table = main.querySelector(".table-card table tbody");
    if (table) orders().forEach(order => table.insertAdjacentHTML("afterbegin", `<tr><td>${order.date}</td><td>Top-up</td><td>${order.item}</td><td class="positive">+${order.item.match(/\d+/)?.[0] || ""}</td><td>${order.balance}</td><td>${order.status}</td></tr>`));
    const topupRows = orders().map(o => ({ id: o.id, channel: "External payment", case: o.item, status: `${o.amount} · ${o.status}`, action: `Issued points. Wallet balance: ${o.balance}` }));
    cta.insertAdjacentHTML("afterend", `${platformRulesHero("Point wallet rules")}<section class="cx-info-grid"><div class="cx-info-card"><h3>Point balance</h3><strong data-point-balance>${balance()} points</strong><p class="cx-muted">Permanent validity. No expiry.</p></div><div class="cx-info-card"><h3>Withdrawable cash</h3><strong>Not available</strong><p class="cx-muted">Points cannot be converted to cash or withdrawn.</p></div><div class="cx-info-card"><h3>Usage scope</h3><strong>Course / Content</strong><p class="cx-muted">External payment is only for point top-up.</p></div></section>${ledgerTable("Payment channels", paymentChannels)}${ledgerTable("Top-up orders / payment records", topupRows)}${ledgerTable("Seller frozen / release ledger", sellerLedger)}${ledgerTable("Abnormal payment and refund handling", abnormalRefunds)}`);
  }
  function enhanceSidebar() {
    const wallet = [...document.querySelectorAll(".sidebar nav a")].find(a => a.textContent.includes("Points Wallet"));
    if (wallet && !document.querySelector("[data-buy-points-nav]")) wallet.insertAdjacentHTML("afterend", `<a href="#/buy-points" data-buy-points-nav>Buy Points</a>`);
    setBalance(balance());
  }

  function enhanceCart(main) {
    if (!main || main.dataset.cxCartEnhanced) return;
    main.dataset.cxCartEnhanced = "true";
    const anchor = main.querySelector(".topbar") || main.firstElementChild;
    anchor?.insertAdjacentHTML("afterend", `${platformRulesHero("Checkout uses platform points only")}<section class="cx-info-grid"><div class="cx-info-card"><h3>External payment</h3><strong>Disabled here</strong><p class="cx-muted">Cards/PayNow/wallets are only used on Buy Points.</p></div><div class="cx-info-card"><h3>Course / Content checkout</h3><strong>Points</strong><p class="cx-muted">Buyer spends wallet points for all platform items.</p></div><div class="cx-info-card"><h3>Seller settlement</h3><strong>Frozen</strong><p class="cx-muted">100% seller points freeze until first access or refund decision.</p></div></section>`);
  }

  function enhanceCheckoutSuccess(main) {
    if (!main || main.dataset.cxCheckoutEnhanced) return;
    main.dataset.cxCheckoutEnhanced = "true";
    const box = main.querySelector(".success") || main.querySelector(".panel") || main;
    box.insertAdjacentHTML("afterend", `${ledgerTable("Post-purchase settlement created", sellerLedger.filter(r => r.state === "Frozen"))}<section class="cx-info-grid"><div class="cx-info-card"><h3>Buyer</h3><p class="cx-muted">Points deducted from wallet. Refund returns points, not cash.</p></div><div class="cx-info-card"><h3>Seller</h3><p class="cx-muted">Receives 100% points in frozen balance.</p></div><div class="cx-info-card"><h3>Release</h3><p class="cx-muted">First valid access releases seller points.</p></div></section>`);
  }

  function enhance() {
    const path = routePath().split("?")[0];
    const root = document.getElementById("root");
    if (!root) return;
    if (path === "/buy-points") {
      const step = new URLSearchParams((location.hash.split("?")[1] || "")).get("step") || "plan";
      if (root.dataset.cxCustomRoute !== `buy-points-${step}`) buyPointsPage();
      return;
    }
    if (path === "/points-success") { if (root.dataset.cxCustomRoute !== "points-success") successPage(); return; }
    root.dataset.cxCustomRoute = "";
    const main = document.querySelector("main");
    if (!main) return;
    enhanceSidebar();
    const title = main.querySelector(".topbar h1");
    const pageTitle = path === "/courses" ? "Course Marketplace" : path.startsWith("/courses/") ? "Course Detail" : path === "/purchases" ? "My Courses & Contents" : path.startsWith("/refund/") ? "Refund Request" : path === "/trainer/course-editor" ? "Trainer Course Publish/Edit" : null;
    if (pageTitle && title?.textContent !== pageTitle) title.textContent = pageTitle;
    if (path === "/courses") enhanceMarketplace(main);
    else if (path === "/contents") enhanceContents(main);
    else if (path === "/cart") enhanceCart(main);
    else if (path === "/checkout-success") enhanceCheckoutSuccess(main);
    else if (/^\/courses\/[^/]+$/.test(path)) enhanceDetail(main);
    else if (path === "/purchases") enhancePurchases(main);
    else if (/^\/refund\/[^/]+$/.test(path)) enhanceRefund(main);
    else if (path === "/trainer/course-editor") enhanceEditor(main);
    else if (path === "/wallet") enhanceWallet(main);
  }

  let queued = false;
  const observer = new MutationObserver(() => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => { queued = false; enhance(); });
  });
  observer.observe(document.getElementById("root"), { childList: true, subtree: true });
  window.addEventListener("hashchange", () => setTimeout(enhance));
  enhance();
})();
