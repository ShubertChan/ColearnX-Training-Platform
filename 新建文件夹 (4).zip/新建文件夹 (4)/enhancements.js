(() => {
  const DAY = 86400000;
  const courses = {
    "ai-basics": {
      title: "AI Basics Training Course", trainer: "Trainer A", category: "AI", price: 80,
      purchased: false, mode: "offline", access: "cloud", duration: "45 min", total: 45, watched: 0,
      structure: "single", location: "CoLearnX Studio A",
      sessions: [{ topic: "AI foundations and prompt practice", date: "12 Jul 2026", time: "10:00-10:45", duration: "45 min", location: "CoLearnX Studio A" }]
    },
    "web-design": {
      title: "Web Design Bootcamp", trainer: "Trainer B", category: "Design", price: 120,
      purchased: true, mode: "offline", access: "cloud", duration: "3 hr", total: 180, watched: 45,
      structure: "series", location: "CoLearnX Studio B",
      sessions: [
        { topic: "Layout foundations", date: "14 Jul 2026", time: "19:00-19:45", duration: "45 min", location: "Studio B", status: "Completed" },
        { topic: "Typography and colour", date: "16 Jul 2026", time: "19:00-19:45", duration: "45 min", location: "Studio B", status: "Next" },
        { topic: "Responsive design", date: "21 Jul 2026", time: "19:00-19:45", duration: "45 min", location: "Studio B", status: "Upcoming" },
        { topic: "Portfolio critique", date: "23 Jul 2026", time: "19:00-19:45", duration: "45 min", location: "Studio B", status: "Upcoming" }
      ]
    },
    cybersecurity: {
      title: "Cybersecurity Intro", trainer: "Trainer C", category: "Security", price: 100,
      purchased: true, mode: "online", delivery: "live", duration: "1 hr", total: 60, watched: 25,
      structure: "single", startsAt: "2026-08-03T20:00:00+08:00",
      sessions: [{ topic: "Live cybersecurity essentials", date: "03 Aug 2026", time: "20:00-21:00", duration: "60 min", location: "Live classroom" }]
    },
    "javascript-starter": {
      title: "JavaScript Starter", trainer: "Trainer D", category: "Code", price: 70,
      purchased: true, mode: "online", delivery: "vod", duration: "2 hr", total: 120, watched: 42,
      structure: "series", startsAt: "2026-08-15T09:00:00+08:00",
      sessions: [
        { topic: "Variables and data types", date: "Lesson 1", time: "12 min", duration: "12 min", location: "VOD", status: "Completed" },
        { topic: "Functions", date: "Lesson 2", time: "18 min", duration: "18 min", location: "VOD", status: "Watching" },
        { topic: "Arrays and objects", date: "Lesson 3", time: "24 min", duration: "24 min", location: "VOD", status: "Locked" },
        { topic: "Browser project", date: "Lesson 4", time: "66 min", duration: "66 min", location: "VOD", status: "Locked" }
      ]
    }
  };

  const ids = Object.keys(courses);
  const editorState = { mode: "online", onlineType: "vod", offlineType: "single", access: "cloud", sessions: 3, chapters: 3 };
  const draftKey = "colearnx-course-draft-v2";

  const icon = (name, size = 17) => {
    const paths = {
      clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
      play: '<path d="m8 5 11 7-11 7z"/>', check: '<path d="m5 12 4 4L19 6"/>',
      calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
      download: '<path d="M12 3v12m0 0 5-5m-5 5-5-5M5 21h14"/>',
      users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8M22 21v-2a4 4 0 0 0-3-3.87"/>',
      grip: '<path d="M9 5h.01M15 5h.01M9 12h.01M15 12h.01M9 19h.01M15 19h.01"/>'
    };
    return `<svg class="cx-icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.check}</svg>`;
  };

  const styles = `
    .cx-toolbar{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;margin:0 0 18px;flex-wrap:wrap}.cx-filter-stack{display:flex;gap:13px;flex-wrap:wrap;align-items:flex-end}.cx-filter-block label{display:block;color:#667085;font-size:11px;font-weight:800;letter-spacing:.04em;margin-bottom:6px;text-transform:uppercase}.cx-filter-group{display:flex;gap:6px;flex-wrap:wrap}.cx-filter{border:1px solid #dce2ef;background:#fff;color:#586174;min-height:34px;padding:0 12px;border-radius:999px;font-size:12px}.cx-filter.active{border-color:#3857f6;background:#eef1ff;color:#263db7}.cx-muted{color:#667085;font-size:13px}
    .cx-badge{display:inline-flex;align-items:center;gap:5px;white-space:nowrap;border-radius:999px;padding:5px 9px;background:#f1f4f9;color:#526074;font-size:12px;font-weight:800}.cx-badge.vod{background:#f1ebff;color:#6d3fc0}.cx-badge.live{background:#fff0f0;color:#c03b49}.cx-badge.owned{background:#e9f8ef;color:#147a43}.cx-badge.series{background:#fff6df;color:#936300}.cx-badge.offline{background:#eaf6ff;color:#176a9c}.cx-badge.danger{background:#fff0f0;color:#b42318}
    .cx-course-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.cx-course-card{background:#fff;border:1px solid #e1e6f0;border-radius:14px;overflow:hidden;box-shadow:0 12px 32px #2a31480c;transition:.18s ease}.cx-course-card:hover{transform:translateY(-2px);box-shadow:0 18px 42px #2a314817}.cx-cover{height:132px;padding:18px;display:flex;justify-content:space-between;align-items:flex-start;background:linear-gradient(135deg,#273bb2,#6d5dfc);color:#fff}.cx-cover.design{background:linear-gradient(135deg,#7b2cbf,#d16ba5)}.cx-cover.security{background:linear-gradient(135deg,#075985,#0891b2)}.cx-cover.code{background:linear-gradient(135deg,#111827,#374151)}.cx-cover-mark{font-size:35px;font-weight:900;opacity:.92}.cx-card-body{padding:19px}.cx-card-body h3{font-size:19px;margin:0 0 5px}.cx-trainer{color:#667085;font-size:13px}.cx-card-meta{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin:16px 0}.cx-meta{display:flex;gap:7px;align-items:center;color:#586174;font-size:13px}.cx-card-footer{display:flex;justify-content:space-between;align-items:center;gap:12px;border-top:1px solid #edf0f6;padding-top:15px}.cx-price{font-size:20px;font-weight:900;color:#263db7}.cx-empty{display:none;text-align:center;background:#fff;border:1px dashed #bcc5d6;border-radius:14px;padding:55px 20px}.cx-empty.show{display:block}.cx-empty strong{display:block;font-size:18px;margin-bottom:6px}
    .cx-progress{min-width:140px}.cx-progress-head{display:flex;justify-content:space-between;gap:10px;margin-bottom:7px;color:#667085;font-size:12px}.cx-track{height:7px;background:#e7ebf3;border-radius:999px;overflow:hidden}.cx-track span{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,#3857f6,#7c5cff)}.cx-progress-card{margin-top:14px;padding-top:14px;border-top:1px solid #dce2ef}.cx-owned-box strong{font-size:20px!important;color:#15803d!important}.cx-owned-box .cx-badge{margin-bottom:10px}
    .cx-schedule{margin-top:18px}.cx-schedule-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px}.cx-schedule h3{margin:0}.cx-series-summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin:12px 0 18px}.cx-series-stat{background:#f6f8fc;border-radius:9px;padding:12px}.cx-series-stat strong{display:block;font-size:17px}.cx-series-stat span{color:#667085;font-size:12px}.cx-session{display:grid;grid-template-columns:34px minmax(0,1fr) auto;gap:12px;align-items:start;padding:14px 0;border-top:1px solid #edf0f6}.cx-session svg{color:#3857f6;margin-top:2px}.cx-session strong{display:block}.cx-session span{display:block;color:#667085;font-size:13px;margin-top:3px}.cx-session-time{text-align:right;color:#526074;font-size:12px;white-space:nowrap}
    .cx-rule{margin-top:18px;border-radius:12px;padding:17px;border:1px solid #dce2ef;background:#fff}.cx-rule.eligible{border-color:#9dd9b6;background:#f2fbf6}.cx-rule.ineligible{border-color:#efb2b2;background:#fff7f7}.cx-rule h3{margin:0 0 7px}.cx-rule p{margin:4px 0}.cx-warning{display:flex;gap:10px;background:#fff8e6;border:1px solid #f5d38b;border-radius:9px;color:#7a4d00;padding:12px;margin-top:12px;font-size:13px}
    .cx-modal-backdrop{position:fixed;inset:0;background:#17203380;z-index:40;display:grid;place-items:center;padding:20px}.cx-modal{background:#fff;border-radius:14px;box-shadow:0 24px 80px #1720334d;max-width:620px;width:100%;padding:24px}.cx-modal h2{margin-bottom:8px}.cx-modal .actions{justify-content:flex-end}.cx-preview-list{background:#f6f8fc;border-radius:10px;padding:14px;margin:14px 0}.cx-preview-list p{margin:6px 0}
    .cx-editor-section{border:1px solid #e1e6f0;border-radius:10px;background:#fafbfe;padding:18px}.cx-section-heading{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:14px}.cx-section-heading h3{margin:0 0 4px}.cx-section-heading p{margin:0;font-size:13px}.cx-segmented{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.cx-option{border:1px solid #dce2ef;background:#fff;min-height:72px;padding:12px;text-align:left;display:block}.cx-option strong,.cx-option span{display:block}.cx-option span{font-size:12px;color:#667085;margin-top:3px;font-weight:500}.cx-option.active{border:2px solid #3857f6;background:#eef1ff;color:#263db7}
    .cx-fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:14px}.cx-field label{display:block;color:#596579;font-size:12px;font-weight:800;margin-bottom:6px}.cx-field input,.cx-field select{width:100%;min-height:44px;margin:0!important;border:1px solid #dce2ef;border-radius:8px;background:#fff;padding:10px 12px}.cx-field .invalid{border-color:#d92d20;background:#fff7f7}.cx-error{display:block;color:#b42318;font-size:12px;margin-top:5px}.cx-series-list{display:flex;flex-direction:column;gap:9px;margin-top:14px}.cx-series-row{display:grid;grid-template-columns:32px 28px minmax(0,1fr) 180px 32px;gap:8px;align-items:center;background:#fff;border:1px solid #e5e9f1;border-radius:9px;padding:8px}.cx-grip{color:#98a2b3;cursor:grab}.cx-series-row b{display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:#eef1ff;color:#3857f6;font-size:12px}.cx-icon-btn{border:0;background:#f3f5fa;color:#596579;min-height:30px;width:30px;padding:0}.cx-add-session{align-self:flex-start;margin-top:10px}.cx-summary{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:13px;color:#667085;font-size:13px}.cx-autosave{display:flex;align-items:center;gap:7px;color:#667085;font-size:12px;margin-left:auto}.cx-validation{display:none;background:#fff0f0;border:1px solid #efb2b2;border-radius:9px;color:#9f1d1d;padding:12px}.cx-validation.show{display:block}
    .tabs button.active{background:#3857f6;color:#fff}.cx-toast{position:fixed;right:24px;bottom:24px;z-index:60;background:#172033;color:#fff;padding:14px 18px;border-radius:10px;box-shadow:0 14px 40px #17203338;font-weight:700;animation:cx-in .2s ease}@keyframes cx-in{from{opacity:0;transform:translateY(8px)}}
    @media(max-width:980px){.cx-course-grid{grid-template-columns:1fr}.cx-fields,.cx-series-summary{grid-template-columns:1fr}.cx-series-row{grid-template-columns:28px 26px 1fr 32px}.cx-series-row input[type=datetime-local]{grid-column:3}.cx-session{grid-template-columns:30px 1fr}.cx-session-time{grid-column:2;text-align:left}.cx-progress{min-width:110px}}
  `;

  const style = document.createElement("style"); style.textContent = styles; document.head.appendChild(style);
  const routePath = () => location.hash.startsWith("#/") ? location.hash.slice(1) : location.pathname;
  const navigate = path => { if (location.hash.startsWith("#/") || location.pathname.endsWith("index.html")) location.hash = path; else { history.pushState({}, "", path); window.dispatchEvent(new PopStateEvent("popstate")); } };
  const pct = c => Math.min(100, Math.round((c.watched || 0) / (c.total || 1) * 100));
  const downloaded = id => localStorage.getItem(`colearnx-downloaded-${id}`) === "true";
  const courseIdFromText = text => ids.find(id => text.includes(courses[id].title));

  function showToast(message) {
    document.querySelector(".cx-toast")?.remove(); const el = document.createElement("div"); el.className = "cx-toast"; el.textContent = message; document.body.appendChild(el); setTimeout(() => el.remove(), 2600);
  }

  function modal(title, body, confirmLabel, onConfirm) {
    const wrap = document.createElement("div"); wrap.className = "cx-modal-backdrop";
    wrap.innerHTML = `<section class="cx-modal" role="dialog" aria-modal="true"><h2>${title}</h2>${body}<div class="actions"><button class="secondary" data-cancel>Cancel</button>${confirmLabel ? `<button class="primary" data-confirm>${confirmLabel}</button>` : ""}</div></section>`;
    document.body.appendChild(wrap); wrap.querySelector("[data-cancel]").onclick = () => wrap.remove();
    if (confirmLabel) wrap.querySelector("[data-confirm]").onclick = () => { onConfirm?.(); wrap.remove(); };
  }

  function refundInfo(id) {
    const c = courses[id];
    if (c.mode === "offline") {
      const limit = Math.floor(c.total / 5); const isDownloaded = downloaded(id); const eligible = !isDownloaded && (c.watched || 0) <= limit;
      return { eligible, title: isDownloaded ? "Not refundable: downloaded locally" : eligible ? "Refund available" : "Refund unavailable", detail: isDownloaded ? "Local download permanently removes refund eligibility." : `Cloud viewing: watched ${c.watched || 0} min. Refund limit is 1/5 of ${c.total} min (${limit} min).`, rule: "Offline: refundable only while cloud viewing is at or below 1/5 of total duration. No refund after local download." };
    }
    const deadline = new Date(new Date(c.startsAt).getTime() - 3 * DAY); const eligible = Date.now() < deadline.getTime();
    return { eligible, title: eligible ? "Refund available" : "Refund window closed", detail: `Course starts ${new Date(c.startsAt).toLocaleString("en-SG", { dateStyle: "medium", timeStyle: "short" })}. Refund deadline: ${deadline.toLocaleString("en-SG", { dateStyle: "medium", timeStyle: "short" })}.`, rule: "Online: refundable until three days before the course starts." };
  }

  function formatLabel(c) {
    if (c.mode === "online") return `Online / ${c.delivery === "live" ? "Live" : "VOD"}`;
    return `Offline / ${c.access === "cloud" ? "Cloud viewing" : "Local download"}`;
  }

  function badgeClass(c) { return c.mode === "offline" ? "offline" : c.delivery; }
  function progressMarkup(c) { const p = pct(c); return `<div class="cx-progress"><div class="cx-progress-head"><span>Watched ${c.watched || 0} / ${c.total} min</span><strong>${p}%</strong></div><div class="cx-track"><span style="width:${p}%"></span></div></div>`; }

  function courseCard(id, index) {
    const c = courses[id]; const next = c.sessions[0];
    return `<article class="cx-course-card" data-course-id="${id}" data-mode="${c.mode}" data-delivery="${c.mode === "online" ? c.delivery : "cloud download"}" data-status="${c.purchased ? "purchased" : "available"}" data-structure="${c.structure}">
      <div class="cx-cover ${c.category.toLowerCase()}"><span class="cx-cover-mark">${c.category.slice(0,2).toUpperCase()}</span><span class="cx-badge ${badgeClass(c)}">${formatLabel(c)}</span></div>
      <div class="cx-card-body"><h3>${c.title}</h3><span class="cx-trainer">${c.trainer} &middot; ${c.category}</span>
      <div class="cx-card-meta"><span class="cx-meta">${icon("clock")} ${c.duration} total</span><span class="cx-meta">${icon(c.structure === "series" ? "users" : "calendar")} ${c.structure === "series" ? `${c.sessions.length}-class series` : "Single class"}</span><span class="cx-meta">${icon("calendar")} ${next.date}</span><span class="cx-meta">${icon(c.mode === "offline" ? "download" : "play")} ${c.mode === "offline" ? "Cloud or local" : c.delivery === "live" ? "Scheduled live" : "Recorded lessons"}</span></div>
      <div class="cx-card-footer">${c.purchased ? `<div><span class="cx-badge owned">${icon("check",13)} Purchased</span></div>` : `<span class="cx-price">${c.price} points</span>`}<button class="${c.purchased ? "secondary" : "primary"}" data-open-course>${c.purchased ? "Go to learning" : "View & purchase"}</button></div></div></article>`;
  }

  function enhanceMarketplace(main) {
    const heading = [...main.querySelectorAll("h2")].find(el => el.textContent.includes("Browse Trainer Courses"));
    const old = [...main.querySelectorAll(".table-card")].find(el => el.querySelector("table")); if (!old || old.dataset.cxEnhanced) return;
    old.dataset.cxEnhanced = "true"; old.style.display = "none";
    const toolbar = document.createElement("section"); toolbar.className = "cx-toolbar";
    toolbar.innerHTML = `<div class="cx-filter-stack">
      <div class="cx-filter-block"><label>Course mode</label><div class="cx-filter-group" data-group="mode"><button class="cx-filter active" data-value="all">All</button><button class="cx-filter" data-value="online">Online</button><button class="cx-filter" data-value="offline">Offline</button></div></div>
      <div class="cx-filter-block"><label>Format / access</label><div class="cx-filter-group" data-group="delivery"><button class="cx-filter active" data-value="all">All</button><button class="cx-filter" data-value="live">Live</button><button class="cx-filter" data-value="vod">VOD</button><button class="cx-filter" data-value="cloud">Cloud</button><button class="cx-filter" data-value="download">Local download</button></div></div>
      <div class="cx-filter-block"><label>Purchase</label><div class="cx-filter-group" data-group="status"><button class="cx-filter active" data-value="all">All</button><button class="cx-filter" data-value="purchased">Purchased</button><button class="cx-filter" data-value="available">Available</button></div></div>
      <div class="cx-filter-block"><label>Structure</label><div class="cx-filter-group" data-group="structure"><button class="cx-filter active" data-value="all">All</button><button class="cx-filter" data-value="single">Single</button><button class="cx-filter" data-value="series">Series</button></div></div>
      </div><span class="cx-muted" data-result-count>4 courses</span>`;
    const grid = document.createElement("section"); grid.className = "cx-course-grid"; grid.innerHTML = ids.map(courseCard).join("");
    const empty = document.createElement("div"); empty.className = "cx-empty"; empty.innerHTML = `<strong>No matching courses</strong><span class="cx-muted">Try clearing one or more filters.</span><br><button class="secondary" data-clear-filters>Clear filters</button>`;
    heading.insertAdjacentElement("afterend", toolbar); toolbar.insertAdjacentElement("afterend", grid); grid.insertAdjacentElement("afterend", empty);
    const applyFilters = () => {
      const selected = {}; toolbar.querySelectorAll("[data-group]").forEach(group => selected[group.dataset.group] = group.querySelector(".active").dataset.value);
      let count = 0; grid.querySelectorAll(".cx-course-card").forEach(card => { const show = Object.entries(selected).every(([key,val]) => val === "all" || card.dataset[key].split(" ").includes(val)); card.hidden = !show; if (show) count++; });
      toolbar.querySelector("[data-result-count]").textContent = `${count} course${count === 1 ? "" : "s"}`; empty.classList.toggle("show", count === 0);
    };
    toolbar.onclick = event => { const button = event.target.closest(".cx-filter"); if (!button) return; const group = button.closest("[data-group]"); group.querySelectorAll(".cx-filter").forEach(el => el.classList.toggle("active", el === button)); applyFilters(); };
    grid.onclick = event => { const card = event.target.closest("[data-course-id]"); if (card) navigate(`/courses/${card.dataset.courseId}`); };
    empty.querySelector("[data-clear-filters]").onclick = () => { toolbar.querySelectorAll("[data-group]").forEach(group => { group.querySelectorAll(".cx-filter").forEach((el,i) => el.classList.toggle("active", i === 0)); }); applyFilters(); };
  }

  function scheduleMarkup(c) {
    const title = c.structure === "series" ? "Complete series timetable" : c.mode === "online" && c.delivery === "vod" ? "VOD lesson outline" : "Class schedule";
    return `<section class="panel cx-schedule"><div class="cx-schedule-head"><h3>${title}</h3><span class="cx-badge ${c.structure === "series" ? "series" : ""}">${c.structure === "series" ? `${c.sessions.length}-class series` : "Single class"}</span></div>
      ${c.structure === "series" ? `<div class="cx-series-summary"><div class="cx-series-stat"><strong>${c.sessions.length}</strong><span>Total classes</span></div><div class="cx-series-stat"><strong>${c.duration}</strong><span>Total duration</span></div><div class="cx-series-stat"><strong>Full bundle</strong><span>Purchased together</span></div></div>` : ""}
      ${c.sessions.map((s,i) => `<div class="cx-session">${icon(c.mode === "online" && c.delivery === "vod" ? "play" : "calendar",18)}<div><strong>${c.structure === "series" ? `Class ${i+1}: ` : ""}${s.topic}</strong><span>${s.location} &middot; ${s.duration}${s.status ? ` &middot; ${s.status}` : ""}</span></div><div class="cx-session-time"><b>${s.date}</b><br>${s.time}</div></div>`).join("")}</section>`;
  }

  function ruleMarkup(id) {
    const c = courses[id], info = refundInfo(id); if (!c.purchased) return `<section class="cx-rule" data-refund-rule><h3>Refund policy before purchase</h3><p>${info.rule}</p>${c.mode === "offline" ? '<div class="cx-warning">Downloading the course to a local device removes refund eligibility.</div>' : `<p class="cx-muted">Current refund deadline: ${info.detail.split("Refund deadline: ")[1] || "three days before start"}</p>`}</section>`; return `<section class="cx-rule ${info.eligible ? "eligible" : "ineligible"}" data-refund-rule><h3>${info.title}</h3><p>${info.detail}</p><p class="cx-muted">${info.rule}</p></section>`;
  }

  function enhanceDetail(main) {
    const id = routePath().split("/").filter(Boolean)[1], c = courses[id], hero = main.querySelector(".detail-hero"); if (!c || !hero || hero.dataset.cxEnhanced === id) return;
    main.querySelectorAll(".cx-schedule,.cx-rule").forEach(el => el.remove()); hero.dataset.cxEnhanced = id; const eyebrow = hero.querySelector(".eyebrow"); if (eyebrow) eyebrow.innerHTML = `${c.category} &middot; <span class="cx-badge ${badgeClass(c)}">${formatLabel(c)}</span>`;
    const priceBox = hero.querySelector(".price-box"); if (c.purchased && priceBox) { priceBox.classList.add("cx-owned-box"); priceBox.innerHTML = `<span class="cx-badge owned">${icon("check",13)} Purchased</span><strong>Ready to learn</strong><div class="cx-progress-card">${progressMarkup(c)}</div>`; }
    const panels = [...main.querySelectorAll(".grid.two .panel")]; const refundPanel = panels.find(p => p.querySelector("h3")?.textContent === "Refund Rules"); if (refundPanel) refundPanel.remove();
    const actions = main.querySelector(".actions"); actions?.insertAdjacentHTML("beforebegin", `${scheduleMarkup(c)}${ruleMarkup(id)}`);
    if (actions && c.purchased) {
      actions.innerHTML = `<button class="primary" data-learn-now>${icon("play")} Go to learning</button>${c.mode === "offline" ? `<button class="secondary" data-download ${downloaded(id) ? "disabled" : ""}>${icon("download")} ${downloaded(id) ? "Downloaded locally" : "Download to device"}</button>` : ""}<button class="ghost" data-refund ${refundInfo(id).eligible ? "" : "disabled"}>Request refund</button>`;
      actions.querySelector("[data-learn-now]").onclick = () => showToast("Learning opened at your last position");
      actions.querySelector("[data-refund]").onclick = () => navigate(`/refund/${id}`);
      const dl = actions.querySelector("[data-download]"); if (dl && !dl.disabled) dl.onclick = () => modal("Download to this device?", `<div class="cx-warning"><b>Important:</b><span>After the course is downloaded locally, it cannot be refunded. This action cannot be undone.</span></div><p>The cloud version will remain available in My Purchases.</p>`, "Download and waive refund", () => { localStorage.setItem(`colearnx-downloaded-${id}`, "true"); dl.disabled = true; dl.innerHTML = `${icon("check")} Downloaded locally`; const rule = main.querySelector("[data-refund-rule]"); if (rule) rule.outerHTML = ruleMarkup(id); actions.querySelector("[data-refund]").disabled = true; showToast("Download started. Refund eligibility removed."); });
    } else if (actions) [...actions.querySelectorAll("button")].filter(button => button.textContent.includes("Refund")).forEach(button => button.remove());
  }

  function enhancePurchases(main) {
    const table = [...main.querySelectorAll(".table-card")].find(el => el.querySelector("h3")?.textContent === "Courses"); if (!table || table.dataset.cxEnhanced) return; table.dataset.cxEnhanced = "true";
    table.querySelector("thead tr").innerHTML = "<th>Course</th><th>Format</th><th>Progress</th><th>Refund</th><th></th>";
    table.querySelectorAll("tbody tr").forEach(row => { const id = courseIdFromText(row.textContent); if (!id) return; const c = courses[id]; if (!c.purchased) { row.remove(); return; } const info = refundInfo(id), status = !c.watched ? "Unwatched" : pct(c) >= 100 ? "Watched" : "Watching"; row.dataset.learningStatus = status; row.innerHTML = `<td><strong>${c.title}</strong><br><span class="cx-badge owned">Purchased</span></td><td><span class="cx-badge ${badgeClass(c)}">${formatLabel(c)}</span></td><td>${progressMarkup(c)}</td><td><span class="cx-badge ${info.eligible ? "owned" : "danger"}">${info.eligible ? "Eligible" : "Not eligible"}</span></td><td><button class="primary mini" data-open>${c.watched ? "Continue" : "Start"}</button></td>`; row.querySelector("[data-open]").onclick = () => navigate(`/courses/${id}`); });
    const empty = document.createElement("div"); empty.className = "cx-empty"; empty.innerHTML = `<strong>No courses in this state</strong><span class="cx-muted">Your courses will appear here when their learning status changes.</span>`; table.appendChild(empty);
    const tabs = main.querySelector(".tabs"); if (tabs) { const buttons = [...tabs.querySelectorAll("button")]; const apply = label => { let count = 0; table.querySelectorAll("tbody tr").forEach(row => { const show = row.dataset.learningStatus === label; row.hidden = !show; if (show) count++; }); empty.classList.toggle("show", count === 0); buttons.forEach(button => button.classList.toggle("active", button.textContent.trim() === label)); }; tabs.onclick = event => { const button = event.target.closest("button"); if (button) apply(button.textContent.trim()); }; apply("Watching"); }
  }

  function enhanceRefund(main) {
    const id = routePath().split("/").filter(Boolean)[1], c = courses[id]; if (!c || main.querySelector("[data-cx-refund]")) return; const info = refundInfo(id);
    const grid = main.querySelector(".grid.two"); if (grid) { grid.dataset.cxRefund = "true"; grid.innerHTML = `<section class="panel"><h3>Course and access</h3><p><b>${c.title}</b></p><p>${formatLabel(c)}</p><p>Watched: ${c.watched || 0} / ${c.total} min</p></section><section class="panel"><h3>Refund eligibility</h3><span class="cx-badge ${info.eligible ? "owned" : "danger"}">${info.title}</span><p>${info.detail}</p><p class="cx-muted">${info.rule}</p></section>`; }
    const form = [...main.querySelectorAll(".panel")].find(p => p.querySelector("textarea")); if (form) { form.insertAdjacentHTML("afterbegin", `<div class="cx-validation ${info.eligible ? "" : "show"}">${info.eligible ? "" : `This request cannot be submitted: ${info.title}.`}</div>`); const submit = [...form.querySelectorAll("button")].find(b => b.textContent.includes("Submit")); if (submit) { submit.disabled = !info.eligible; submit.textContent = info.eligible ? "Submit refund request" : "Refund unavailable"; } }
  }

  function loadDraft(editor) { try { const d = JSON.parse(localStorage.getItem(draftKey) || "{}"); [["Course Title",d.title],["Point Price",d.price],["Capacity",d.capacity]].forEach(([p,v]) => { const el=editor.querySelector(`input[placeholder="${p}"]`); if(el&&v) el.value=v; }); const ta=editor.querySelector("textarea"); if(ta&&d.description) ta.value=d.description; } catch {} }
  function saveDraft(editor) { const d={title:editor.querySelector('input[placeholder="Course Title"]')?.value,price:editor.querySelector('input[placeholder="Point Price"]')?.value,capacity:editor.querySelector('input[placeholder="Capacity"]')?.value,description:editor.querySelector("textarea")?.value,mode:editorState.mode,updated:new Date().toISOString()}; localStorage.setItem(draftKey,JSON.stringify(d)); const status=editor.querySelector("[data-autosave]"); if(status) status.innerHTML=`${icon("check",13)} Draft autosaved ${new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}`; }

  function rowsMarkup(count, kind) { return Array.from({length:count},(_,i)=>`<div class="cx-series-row" draggable="true" data-sort-row><span class="cx-grip" title="Drag to reorder">${icon("grip",18)}</span><b>${i+1}</b><input data-row-title value="${kind === "chapter" ? `Lesson ${i+1}: ${["Introduction","Core concepts","Guided project"][i]||"New lesson"}` : `Class ${i+1}: ${["Foundations","Guided practice","Final project"][i]||"New class"}`}" aria-label="${kind} ${i+1} title"><input type="${kind === "chapter" ? "text" : "datetime-local"}" value="${kind === "chapter" ? ["12 min","24 min","45 min"][i]||"30 min" : `2026-07-${String(14+i*2).padStart(2,"0")}T19:00`}" aria-label="${kind} ${i+1} timing"><button type="button" class="cx-icon-btn" data-remove-row title="Remove">x</button></div>`).join(""); }

  function onlineMarkup() { const vod=editorState.onlineType==="vod"; return `<div class="cx-fields"><div class="cx-field"><label>Delivery method *</label><select data-online-type><option value="vod" ${vod?"selected":""}>VOD / Recorded</option><option value="live" ${!vod?"selected":""}>Live online</option></select></div><div class="cx-field"><label>Timezone *</label><select data-required><option value="Asia/Singapore">Asia/Singapore (GMT+8)</option><option>UTC</option></select></div><div class="cx-field"><label>Total duration *</label><input data-required value="2 hr" placeholder="e.g. 2 hr"></div>${vod?'<div class="cx-field"><label>Access period</label><select><option>Lifetime access</option><option>90 days</option><option>180 days</option></select></div>':'<div class="cx-field"><label>Course start *</label><input data-required type="datetime-local" value="2026-08-03T20:00"></div>'}</div>${vod?`<div class="cx-section-heading" style="margin-top:18px"><div><h3>Recorded lessons</h3><p>Upload, name and reorder the VOD chapters.</p></div><span class="cx-badge vod">${editorState.chapters} lessons</span></div><div class="cx-series-list" data-sort-list>${rowsMarkup(editorState.chapters,"chapter")}</div><button type="button" class="secondary mini cx-add-session" data-add-chapter>+ Add lesson</button>`:""}<div class="cx-summary"><span class="cx-badge ${vod?"vod":"live"}">${vod?"VOD":"Live"}</span><span>${vod?"Available on demand after purchase.":"Refundable until three days before the scheduled start."}</span></div>`; }
  function offlineMarkup() { const single=editorState.offlineType==="single"; return `<div class="cx-fields"><div class="cx-field"><label>Course structure *</label><select data-offline-type><option value="single" ${single?"selected":""}>Single class</option><option value="series" ${!single?"selected":""}>Series / course bundle</option></select></div><div class="cx-field"><label>Default access *</label><select data-access><option value="cloud" ${editorState.access==="cloud"?"selected":""}>Cloud viewing</option><option value="download" ${editorState.access==="download"?"selected":""}>Download to local device</option></select></div><div class="cx-field"><label>Venue *</label><input data-required value="CoLearnX Studio A"></div><div class="cx-field"><label>Timezone *</label><select data-required><option>Asia/Singapore (GMT+8)</option><option>UTC</option></select></div></div>${single?'<div class="cx-fields"><div class="cx-field"><label>Class date and time *</label><input data-required type="datetime-local" value="2026-07-12T10:00"></div><div class="cx-field"><label>Duration *</label><input data-required value="45 min"></div></div>':`<div class="cx-section-heading" style="margin-top:18px"><div><h3>Series timetable</h3><p>Drag classes to reorder them. Duplicate dates are checked before publishing.</p></div><span class="cx-badge series">${editorState.sessions} classes</span></div><div class="cx-series-list" data-sort-list>${rowsMarkup(editorState.sessions,"session")}</div><button type="button" class="secondary mini cx-add-session" data-add-session>+ Add class</button>`}<div class="cx-warning">${icon("download",18)}<span>Offline refund rule: cloud viewing is refundable up to 1/5 of total duration. Downloading locally makes the purchase non-refundable.</span></div>`; }
  function editorMarkup(){const online=editorState.mode==="online";return `<div class="cx-editor-section" data-editor-config><div class="cx-section-heading"><div><h3>Course format and structure</h3><p>Configure delivery, access, timetable and refund behaviour.</p></div><span class="cx-badge">Required</span></div><div class="cx-segmented"><button type="button" class="cx-option ${online?"active":""}" data-mode="online"><strong>Online course</strong><span>Live or VOD</span></button><button type="button" class="cx-option ${!online?"active":""}" data-mode="offline"><strong>Offline course</strong><span>Cloud viewing or local download</span></button></div>${online?onlineMarkup():offlineMarkup()}</div>`;}

  function validateEditor(editor){ editor.querySelectorAll(".invalid").forEach(e=>e.classList.remove("invalid")); const errors=[]; [[editor.querySelector('input[placeholder="Course Title"]'),"Course title is required"],[editor.querySelector('input[placeholder="Point Price"]'),"Point price is required"],...Array.from(editor.querySelectorAll("[data-required]")).map(e=>[e,"Complete all required scheduling fields"])].forEach(([el,msg])=>{if(el&&!String(el.value).trim()){el.classList.add("invalid");errors.push(msg);}}); if(editorState.mode==="offline"&&editorState.offlineType==="series"){const values=[...editor.querySelectorAll('[data-sort-row] input[type="datetime-local"]')].map(e=>e.value).filter(Boolean);if(new Set(values).size!==values.length)errors.push("Series classes cannot use duplicate dates and times");} const box=editor.querySelector("[data-validation]");box.textContent=[...new Set(errors)].join(". ");box.classList.toggle("show",errors.length>0);return errors.length===0;}
  function previewEditor(editor){ if(!validateEditor(editor))return; const title=editor.querySelector('input[placeholder="Course Title"]')?.value||"Untitled course", price=editor.querySelector('input[placeholder="Point Price"]')?.value||"0"; modal("Course preview",`<span class="cx-badge ${editorState.mode==="online"?editorState.onlineType:"offline"}">${editorState.mode==="online"?`Online / ${editorState.onlineType.toUpperCase()}`:`Offline / ${editorState.offlineType}`}</span><div class="cx-preview-list"><p><b>${title}</b></p><p>${price} points</p><p>${editorState.mode==="online"&&editorState.onlineType==="vod"?`${editorState.chapters} recorded lessons`:editorState.mode==="offline"&&editorState.offlineType==="series"?`${editorState.sessions} scheduled classes`:"Single scheduled course"}</p><p>Timezone: Asia/Singapore (GMT+8)</p></div><p class="cx-muted">This is how the course configuration will be published.</p>`,null);}

  function enhanceEditor(main){const editor=main.querySelector(".panel.editor");if(!editor||editor.dataset.cxEnhanced)return;editor.dataset.cxEnhanced="true";loadDraft(editor);const capacity=editor.querySelector('input[placeholder="Capacity"]');capacity?.insertAdjacentHTML("afterend",`<div class="cx-validation" data-validation></div>${editorMarkup()}`);const actions=editor.querySelector(".actions");actions?.insertAdjacentHTML("afterbegin",`<button type="button" class="ghost" data-preview>Preview course</button><span class="cx-autosave" data-autosave>Draft autosave ready</span>`);const lock=()=>editor.querySelectorAll("[data-editor-config] button,[data-editor-config] input,[data-editor-config] select").forEach(el=>el.disabled=Boolean(capacity?.disabled));const rerender=()=>{editor.querySelector("[data-editor-config]").outerHTML=editorMarkup();lock();};lock();
    let dragRow=null,saveTimer;editor.addEventListener("input",()=>{clearTimeout(saveTimer);saveTimer=setTimeout(()=>saveDraft(editor),350);});editor.addEventListener("change",e=>{if(e.target.matches("[data-online-type]"))editorState.onlineType=e.target.value;if(e.target.matches("[data-offline-type]"))editorState.offlineType=e.target.value;if(e.target.matches("[data-access]"))editorState.access=e.target.value;if(e.target.matches("[data-online-type],[data-offline-type]"))rerender();saveDraft(editor);});
    editor.addEventListener("dragstart",e=>{dragRow=e.target.closest("[data-sort-row]");dragRow?.classList.add("dragging");});editor.addEventListener("dragover",e=>{const over=e.target.closest("[data-sort-row]");if(dragRow&&over&&over!==dragRow){e.preventDefault();over.parentNode.insertBefore(dragRow,over);}});editor.addEventListener("dragend",()=>{dragRow?.classList.remove("dragging");dragRow=null;saveDraft(editor);});
    editor.addEventListener("click",e=>{const mode=e.target.closest("[data-mode]");if(mode){editorState.mode=mode.dataset.mode;rerender();return;}if(e.target.closest("[data-add-session]")){editorState.sessions++;rerender();return;}if(e.target.closest("[data-add-chapter]")){editorState.chapters++;rerender();return;}const remove=e.target.closest("[data-remove-row]");if(remove){const list=remove.closest("[data-sort-list]");remove.closest("[data-sort-row]").remove();[...list.children].forEach((row,i)=>row.querySelector("b").textContent=i+1);return;}if(e.target.closest("[data-preview]")){previewEditor(editor);return;}const publish=e.target.closest("button.primary");if(publish&&!publish.disabled){if(!validateEditor(editor)){e.stopPropagation();showToast("Please fix the highlighted fields before publishing");}else{localStorage.removeItem(draftKey);showToast("Course published with schedule and refund settings");}}});}

  function enhance(){const main=document.querySelector("main");if(!main)return;const path=routePath(),title=main.querySelector(".topbar h1"),pageTitle=path==="/courses"?"Course Marketplace":path.startsWith("/courses/")?"Course Detail":path==="/purchases"?"My Courses & Contents":path.startsWith("/refund/")?"Refund Request":path==="/trainer/course-editor"?"Trainer Course Publish/Edit":null;if(pageTitle&&title?.textContent!==pageTitle)title.textContent=pageTitle;if(path==="/courses")enhanceMarketplace(main);else if(/^\/courses\/[^/]+$/.test(path))enhanceDetail(main);else if(path==="/purchases")enhancePurchases(main);else if(/^\/refund\/[^/]+$/.test(path))enhanceRefund(main);else if(path==="/trainer/course-editor")enhanceEditor(main);}
  let queued=false;const observer=new MutationObserver(()=>{if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;enhance();});});observer.observe(document.getElementById("root"),{childList:true,subtree:true});window.addEventListener("popstate",()=>setTimeout(enhance));window.addEventListener("hashchange",()=>setTimeout(enhance));enhance();
})();
